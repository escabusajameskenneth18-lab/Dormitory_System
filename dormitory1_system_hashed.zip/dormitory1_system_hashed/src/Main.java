import model.DBConnection;
import view.LoginView;
import javax.swing.*;

/**
 * APPLICATION ENTRY POINT
 * Starts the Dormitory Reservation Management System.
 * Run this class in NetBeans.
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
            catch (Exception ignored) {}
            // Test DB connection first (shows dialog + exits if it fails)
            DBConnection.testConnection();
            new LoginView();
        });
    }
}
