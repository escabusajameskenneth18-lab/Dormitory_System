package model;


public class Reservation {
    private String resCode;
    private String studentName;
    private String studentIdRef;
    private String roomNo;
    private String status;
    private String dateIn;
    private String dateOut;
    private String notes;
    private String createdBy;
    private String createdAt;

    public Reservation() {}

    // Getters
    public String getResCode()      { return resCode; }
    public String getStudentName()  { return studentName; }
    public String getStudentIdRef() { return studentIdRef; }
    public String getRoomNo()       { return roomNo; }
    public String getStatus()       { return status; }
    public String getDateIn()       { return dateIn; }
    public String getDateOut()      { return dateOut; }
    public String getNotes()        { return notes; }
    public String getCreatedBy()    { return createdBy; }
    public String getCreatedAt()    { return createdAt; }

    // Setters
    public void setResCode(String resCode)           { this.resCode = resCode; }
    public void setStudentName(String studentName)   { this.studentName = studentName; }
    public void setStudentIdRef(String studentIdRef) { this.studentIdRef = studentIdRef; }
    public void setRoomNo(String roomNo)             { this.roomNo = roomNo; }
    public void setStatus(String status)             { this.status = status; }
    public void setDateIn(String dateIn)             { this.dateIn = dateIn; }
    public void setDateOut(String dateOut)           { this.dateOut = dateOut; }
    public void setNotes(String notes)               { this.notes = notes; }
    public void setCreatedBy(String createdBy)       { this.createdBy = createdBy; }
    public void setCreatedAt(String createdAt)       { this.createdAt = createdAt; }
}
