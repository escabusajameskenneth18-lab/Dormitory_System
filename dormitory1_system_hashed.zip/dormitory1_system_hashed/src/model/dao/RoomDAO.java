package model.dao;

import model.DBConnection;
import model.Room;
import java.sql.*;
import java.util.*;


public class RoomDAO {

    public List<Room> getAll() {
        List<Room> list = new ArrayList<>();
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "SELECT room_no, room_type, capacity, floor_no, monthly_rate, status, IFNULL(reserved_by,'') " +
                "FROM rooms ORDER BY floor_no, room_no");
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Room(
                    rs.getString(1), rs.getString(2), rs.getInt(3),
                    rs.getInt(4),    rs.getDouble(5), rs.getString(6), rs.getString(7)
                ));
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        finally { DBConnection.close(rs, ps); }
        return list;
    }

    public Room getByRoomNo(String roomNo) {
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement("SELECT * FROM rooms WHERE room_no=?");
            ps.setString(1, roomNo); rs = ps.executeQuery();
            if (rs.next()) {
                return new Room(
                    rs.getString("room_no"), rs.getString("room_type"),
                    rs.getInt("capacity"),   rs.getInt("floor_no"),
                    rs.getDouble("monthly_rate"), rs.getString("status"),
                    rs.getString("reserved_by") == null ? "" : rs.getString("reserved_by")
                );
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        finally { DBConnection.close(rs, ps); }
        return null;
    }

    public void insert(Room r) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "INSERT INTO rooms(room_no, room_type, capacity, floor_no, monthly_rate, status) VALUES(?,?,?,?,?,?)");
            ps.setString(1, r.getRoomNo());      ps.setString(2, r.getRoomType());
            ps.setInt(3, r.getCapacity());        ps.setInt(4, r.getFloorNo());
            ps.setDouble(5, r.getMonthlyRate()); ps.setString(6, r.getStatus());
            ps.executeUpdate();
        } finally { DBConnection.close(null, ps); }
    }

    public void update(Room r) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "UPDATE rooms SET room_type=?, capacity=?, floor_no=?, monthly_rate=?, status=? WHERE room_no=?");
            ps.setString(1, r.getRoomType()); ps.setInt(2, r.getCapacity());
            ps.setInt(3, r.getFloorNo());     ps.setDouble(4, r.getMonthlyRate());
            ps.setString(5, r.getStatus());   ps.setString(6, r.getRoomNo());
            ps.executeUpdate();
        } finally { DBConnection.close(null, ps); }
    }

    public void delete(String roomNo) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = DBConnection.get().prepareStatement("DELETE FROM rooms WHERE room_no=?");
            ps.setString(1, roomNo); ps.executeUpdate();
        } finally { DBConnection.close(null, ps); }
    }

    public int getTotalCount()     { return countWhere(null); }
    public int getAvailableCount() { return countWhere("Available"); }
    public int getBookedCount()    { return countWhere("Booked"); }

    private int countWhere(String status) {
        try {
            String sql = status == null
                ? "SELECT COUNT(*) FROM rooms"
                : "SELECT COUNT(*) FROM rooms WHERE status='" + status + "'";
            Statement st = DBConnection.get().createStatement();
            ResultSet rs = st.executeQuery(sql);
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) { return 0; }
    }
}
