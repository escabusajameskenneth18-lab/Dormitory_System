package model.dao;

import model.DBConnection;
import model.Reservation;
import java.sql.*;
import java.util.*;


public class ReservationDAO {

    public List<Reservation> getAll(String filter) {
        List<Reservation> list = new ArrayList<>();
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            String sql = "SELECT res_code, student_name, student_id_ref, room_no, status, " +
                "IFNULL(DATE_FORMAT(date_in,'%Y-%m-%d'),''), " +
                "IFNULL(DATE_FORMAT(date_out,'%Y-%m-%d'),''), " +
                "IFNULL(created_by,''), DATE_FORMAT(created_at,'%Y-%m-%d %H:%i') " +
                "FROM reservations ";
            if (filter != null && !filter.equals("All")) sql += "WHERE status=? ";
            sql += "ORDER BY created_at DESC";
            ps = DBConnection.get().prepareStatement(sql);
            if (filter != null && !filter.equals("All")) ps.setString(1, filter);
            rs = ps.executeQuery();
            while (rs.next()) {
                Reservation r = new Reservation();
                r.setResCode(rs.getString(1));      r.setStudentName(rs.getString(2));
                r.setStudentIdRef(rs.getString(3)); r.setRoomNo(rs.getString(4));
                r.setStatus(rs.getString(5));       r.setDateIn(rs.getString(6));
                r.setDateOut(rs.getString(7));      r.setCreatedBy(rs.getString(8));
                r.setCreatedAt(rs.getString(9));
                list.add(r);
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        finally { DBConnection.close(rs, ps); }
        return list;
    }

    public List<Reservation> getRecent(int limit) {
        List<Reservation> list = new ArrayList<>();
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "SELECT res_code, student_name, student_id_ref, room_no, status, " +
                "IFNULL(DATE_FORMAT(date_in,'%Y-%m-%d'),''), " +
                "IFNULL(DATE_FORMAT(date_out,'%Y-%m-%d'),''), " +
                "DATE_FORMAT(created_at,'%Y-%m-%d %H:%i') " +
                "FROM reservations ORDER BY created_at DESC LIMIT ?");
            ps.setInt(1, limit); rs = ps.executeQuery();
            while (rs.next()) {
                Reservation r = new Reservation();
                r.setResCode(rs.getString(1));      r.setStudentName(rs.getString(2));
                r.setStudentIdRef(rs.getString(3)); r.setRoomNo(rs.getString(4));
                r.setStatus(rs.getString(5));       r.setDateIn(rs.getString(6));
                r.setDateOut(rs.getString(7));      r.setCreatedAt(rs.getString(8));
                list.add(r);
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        finally { DBConnection.close(rs, ps); }
        return list;
    }

    public void insert(Reservation r) throws SQLException {
        PreparedStatement ps = null;
        try {
            // Generate reservation code
            Statement st = DBConnection.get().createStatement();
            ResultSet cnt = st.executeQuery("SELECT COUNT(*)+1 FROM reservations");
            int n = cnt.next() ? cnt.getInt(1) : 1;
            cnt.close(); st.close();
            String code = String.format("RES-%04d", n);
            r.setResCode(code);

            ps = DBConnection.get().prepareStatement(
                "INSERT INTO reservations(res_code, student_name, student_id_ref, room_no, " +
                "status, date_in, date_out, notes, created_by) VALUES(?,?,?,?,'Pending',?,?,?,?)");
            ps.setString(1, code);             ps.setString(2, r.getStudentName());
            ps.setString(3, r.getStudentIdRef()); ps.setString(4, r.getRoomNo());
            ps.setString(5, r.getDateIn());    ps.setString(6, r.getDateOut());
            ps.setString(7, r.getNotes());     ps.setString(8, r.getCreatedBy());
            ps.executeUpdate();
        } finally { DBConnection.close(null, ps); }
    }

    public boolean hasDuplicate(String studentId) throws SQLException {
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "SELECT id FROM reservations WHERE student_id_ref=? AND status IN('Pending','Approved','Checked-In')");
            ps.setString(1, studentId); rs = ps.executeQuery();
            return rs.next();
        } finally { DBConnection.close(rs, ps); }
    }

    public void callProc(String proc, String code, String approvedBy) throws SQLException {
        PreparedStatement ps = null;
        try {
            if ("sp_approve_reservation".equals(proc)) {
                ps = DBConnection.get().prepareStatement("CALL sp_approve_reservation(?,?)");
                ps.setString(1, code); ps.setString(2, approvedBy);
            } else {
                ps = DBConnection.get().prepareStatement("CALL " + proc + "(?)");
                ps.setString(1, code);
            }
            ps.execute();
        } finally { DBConnection.close(null, ps); }
    }

    public void delete(String resCode) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = DBConnection.get().prepareStatement("DELETE FROM reservations WHERE res_code=?");
            ps.setString(1, resCode); ps.executeUpdate();
        } finally { DBConnection.close(null, ps); }
    }

    public int getPendingCount() {
        try {
            Statement st = DBConnection.get().createStatement();
            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM reservations WHERE status='Pending'");
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) { return 0; }
    }

    public String getActiveCodeForRoom(String roomNo) throws SQLException {
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "SELECT res_code FROM reservations WHERE room_no=? AND status IN('Pending','Approved','Checked-In') LIMIT 1");
            ps.setString(1, roomNo); rs = ps.executeQuery();
            return rs.next() ? rs.getString(1) : null;
        } finally { DBConnection.close(rs, ps); }
    }
}
