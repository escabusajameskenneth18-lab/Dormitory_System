package model.dao;

import model.DBConnection;
import model.Session;
import util.PasswordUtil;
import java.sql.*;

/**
 * MODEL LAYER — Data Access Object
 * Handles user authentication.
 *
 * Passwords are stored as SHA-256 hashes in the database.
 * Plain-text passwords are NEVER sent to or compared directly in SQL.
 */
public class UserDAO {

    
    public boolean authenticate(String username, String password) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            // Step 1: Fetch the user record by username only
            ps = DBConnection.get().prepareStatement(
                "SELECT id, username, full_name, role, password FROM users WHERE username = ?");
            ps.setString(1, username);
            rs = ps.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password");

                
                if (PasswordUtil.verify(password, storedHash)) {
                    Session.set(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("full_name"),
                        rs.getString("role")
                    );
                    return true;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            DBConnection.close(rs, ps);
        }
        return false;
    }

    /**
     * Updates a user's password in the database (stores it as a SHA-256 hash).
     * Use this whenever a password needs to be changed.
     *
     * @param userId       the ID of the user to update
     * @param newPassword  the new plain-text password (will be hashed before saving)
     * @return true if update succeeded
     */
    public boolean updatePassword(int userId, String newPassword) {
        PreparedStatement ps = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "UPDATE users SET password = ? WHERE id = ?");
            ps.setString(1, PasswordUtil.hash(newPassword));
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        } finally {
            DBConnection.close(null, ps);
        }
    }
}
