package model;

import java.sql.*;
import javax.swing.*;


public class DBConnection {

    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    private static final String NAME = "dorm_db";
    private static final String USER = "root";
    private static final String PASS = "";   
    private static final String URL =
        "jdbc:mysql://" + HOST + ":" + PORT + "/" + NAME
        + "?useSSL=false&allowPublicKeyRetrieval=true"
        + "&serverTimezone=Asia/Manila&autoReconnect=true";

    private static Connection conn = null;

    public static Connection get() {
        try {
            if (conn == null || conn.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(URL, USER, PASS);
            }
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null,
                "MySQL JDBC Driver not found!\n\n" +
                "Fix:\n" +
                "  1. Download MySQL Connector/J\n" +
                "  2. Right-click project → Properties → Libraries → Add JAR",
                "Driver Not Found", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                "Cannot connect to MySQL!\n\nError: " + ex.getMessage() +
                "\n\nCheck:\n  • MySQL Server is running\n  • USER/PASS are correct\n  • Run dorm_db.sql first",
                "Connection Failed", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        return conn;
    }

    public static boolean testConnection() {
        try { return get() != null && !get().isClosed(); }
        catch (Exception e) { return false; }
    }

    public static void close(ResultSet rs, PreparedStatement ps) {
        try { if (rs != null) rs.close(); } catch (Exception ignored) {}
        try { if (ps != null) ps.close(); } catch (Exception ignored) {}
    }

    public static void close(Statement st) {
        try { if (st != null) st.close(); } catch (Exception ignored) {}
    }
}
