package view;

import controller.MainController;
import controller.RoomController;
import model.Room;
import util.AppTheme;
import util.UIFactory;
import view.renderer.BtnRenderer;
import view.renderer.StatusRenderer;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * VIEW LAYER
 * Manage Rooms panel. Delegates all logic to RoomController.
 */
public class ManageRoomsView extends JPanel {

    RoomController ctrl;

    private JTextField    roomNoFld, capFld, floorFld, rateFld;
    private JComboBox<String> typeCb, statusCb;
    private JLabel        fTitle;
    private JButton       saveBtn;
    private boolean       editMode = false;
    private DefaultTableModel model;
    private JTable        tbl;

    public ManageRoomsView(MainController mainCtrl) {
        ctrl = new RoomController(this, mainCtrl);
        setLayout(new BorderLayout(0, 14));
        setBackground(AppTheme.CONTENT_BG);
        setBorder(new EmptyBorder(22, 24, 22, 24));
        build();
    }

    private void build() {
        add(UIFactory.title("Manage Rooms"), BorderLayout.NORTH);

        JPanel fc = UIFactory.formCard();
        fTitle = new JLabel("Add New Room");
        fTitle.setFont(new Font("Arial", Font.BOLD, 14));
        fTitle.setForeground(AppTheme.TEXT_DARK);
        fc.add(fTitle, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridBagLayout());
        grid.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 5, 5, 10); g.fill = GridBagConstraints.HORIZONTAL;

        roomNoFld = UIFactory.field();
        typeCb    = UIFactory.combo("Single", "Double", "Triple", "Suite");
        capFld    = UIFactory.field(); capFld.setText("1");
        floorFld  = UIFactory.field(); floorFld.setText("1");
        rateFld   = UIFactory.field(); rateFld.setText("3500");
        statusCb  = UIFactory.combo("Available", "Maintenance");

        UIFactory.gridRow(grid, g, 0, "Room No. *", roomNoFld, "Type *",    typeCb);
        UIFactory.gridRow(grid, g, 1, "Capacity",   capFld,    "Floor",     floorFld);
        UIFactory.gridRow(grid, g, 2, "Rate/mo",    rateFld,   "Status",    statusCb);

        g.gridx = 0; g.gridy = 3; g.gridwidth = 1; g.weightx = 0.15;
        saveBtn = AppTheme.makeBtn("Save Room", AppTheme.ACCENT);
        saveBtn.addActionListener(e -> save());
        grid.add(saveBtn, g);

        g.gridx = 1; g.weightx = 0.15;
        JButton cx = AppTheme.makeBtn("Cancel", AppTheme.BTN_GRAY);
        cx.addActionListener(e -> clearForm());
        grid.add(cx, g);
        fc.add(grid, BorderLayout.CENTER);

        // Table
        String[] cols = {"Room No.", "Type", "Cap.", "Floor", "Rate/mo", "Status", "Reserved By", "Actions"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return c == 7; }
        };
        tbl = UIFactory.table(model);
        tbl.getColumnModel().getColumn(5).setCellRenderer(new StatusRenderer());
        tbl.getColumnModel().getColumn(7).setCellRenderer(
            new BtnRenderer(new String[]{"Edit", "Delete"}, new Color[]{AppTheme.ACCENT, AppTheme.S_BOOKED}));
        tbl.getColumnModel().getColumn(7).setCellEditor(new RoomMgEditor(tbl, this));
        tbl.getColumnModel().getColumn(7).setPreferredWidth(160);
        tbl.setRowHeight(38);

        JPanel tc = UIFactory.tableCard();
        JPanel th = new JPanel(new BorderLayout()); th.setOpaque(false); th.setBorder(new EmptyBorder(0, 0, 8, 0));
        th.add(UIFactory.cardTitle("All Rooms"), BorderLayout.WEST);
        JLabel leg = new JLabel("Available   Booked   Maintenance");
        leg.setFont(AppTheme.F_SMALL); leg.setForeground(Color.GRAY); th.add(leg, BorderLayout.EAST);
        tc.add(th, BorderLayout.NORTH); tc.add(UIFactory.scroll(tbl), BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout(0, 12)); center.setOpaque(false);
        center.add(fc, BorderLayout.NORTH); center.add(tc, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        ctrl.loadAll();
    }

    private void save() {
        try {
            Room r = new Room(
                roomNoFld.getText().trim(), (String) typeCb.getSelectedItem(),
                Integer.parseInt(capFld.getText().trim().isEmpty() ? "1" : capFld.getText().trim()),
                Integer.parseInt(floorFld.getText().trim().isEmpty() ? "1" : floorFld.getText().trim()),
                Double.parseDouble(rateFld.getText().trim().isEmpty() ? "3500" : rateFld.getText().trim()),
                (String) statusCb.getSelectedItem(), ""
            );
            ctrl.save(r, editMode);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Capacity, Floor, and Rate must be numbers.", "Validation", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ── Methods called by RoomController ─────────────────────────────────
    public void populateTable(List<Room> rooms) {
        model.setRowCount(0);
        for (Room r : rooms)
            model.addRow(new Object[]{
                r.getRoomNo(), r.getRoomType(), r.getCapacity(), r.getFloorNo(),
                String.format("₱%,.0f", r.getMonthlyRate()), r.getStatus(), r.getReservedBy(), "actions"
            });
        tbl.getColumnModel().getColumn(5).setCellRenderer(new StatusRenderer());
    }

    public void fillFormForEdit(Room r) {
        editMode = true;
        roomNoFld.setText(r.getRoomNo()); roomNoFld.setEditable(false); roomNoFld.setBackground(new Color(0xf0f0f0));
        typeCb.setSelectedItem(r.getRoomType());
        capFld.setText(String.valueOf(r.getCapacity()));
        floorFld.setText(String.valueOf(r.getFloorNo()));
        rateFld.setText(String.valueOf((int) r.getMonthlyRate()));
        String st = r.getStatus(); statusCb.setSelectedItem("Booked".equals(st) ? "Available" : st);
        fTitle.setText("Editing Room: " + r.getRoomNo()); saveBtn.setText("Update");
    }

    public void clearForm() {
        editMode = false;
        roomNoFld.setText(""); roomNoFld.setEditable(true); roomNoFld.setBackground(Color.WHITE);
        typeCb.setSelectedIndex(0); capFld.setText("1"); floorFld.setText("1");
        rateFld.setText("3500"); statusCb.setSelectedIndex(0);
        fTitle.setText("Add New Room"); saveBtn.setText("Save Room");
    }

    public void refresh()                      { ctrl.loadAll(); }
    public Object getTableValueAt(int r, int c){ return model.getValueAt(r, c); }
    public void showMessage(String msg, String title, int type) {
        JOptionPane.showMessageDialog(this, msg, title, type);
    }
    public int confirmDialog(String msg, String title) {
        return JOptionPane.showConfirmDialog(this, msg, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
    }
}

class RoomMgEditor extends DefaultCellEditor {
    private final ManageRoomsView parent;
    RoomMgEditor(JTable t, ManageRoomsView p) { super(new JCheckBox()); this.parent = p; }
    public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int row, int col) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4)); p.setBackground(Color.WHITE);
        JButton e = AppTheme.makeSmallBtn("Edit",   AppTheme.ACCENT);
        JButton d = AppTheme.makeSmallBtn("Delete", AppTheme.S_BOOKED);
        e.addActionListener(ev -> { parent.ctrl.startEdit(row); stopCellEditing(); });
        d.addActionListener(ev -> { parent.ctrl.delete(row);    stopCellEditing(); });
        p.add(e); p.add(d); return p;
    }
    public Object getCellEditorValue() { return "actions"; }
}
