package view.renderer;

import util.AppTheme;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/**
 * VIEW LAYER — Renderer
 * Renders one or two small action buttons inside a table cell.
 */
public class BtnRenderer extends DefaultTableCellRenderer {
    private final String[] labels;
    private final Color[]  colors;

    public BtnRenderer(String[] labels, Color[] colors) {
        this.labels = labels;
        this.colors = colors;
    }

    @Override
    public Component getTableCellRendererComponent(
            JTable t, Object v, boolean sel, boolean foc, int row, int col) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
        p.setBackground(Color.WHITE);
        for (int i = 0; i < labels.length; i++)
            p.add(AppTheme.makeSmallBtn(labels[i], colors[i]));
        return p;
    }
}
