package view;

import controller.ReservationController;
import model.Room;
import model.Student;
import util.AppTheme;
import util.UIFactory;
import view.renderer.StatusRenderer;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * VIEW LAYER
 * Room Reservation panel. Delegates all logic to ReservationController.
 */
public class RoomReservationView extends JPanel {

    final ReservationController ctrl;
    private DefaultTableModel model;
    private JTable tbl;

    public RoomReservationView(ReservationController ctrl) {
        this.ctrl = ctrl;
        setLayout(new BorderLayout(0, 12));
        setBackground(AppTheme.CONTENT_BG);
        setBorder(new EmptyBorder(22, 24, 22, 24));
        build();
    }

    private void build() {
        add(UIFactory.title("Room Reservation"), BorderLayout.NORTH);

        String[] cols = {"Room No.", "Type", "Cap.", "Floor", "Rate/mo", "Status", "Reserved By", "Action"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return c == 7; }
        };
        tbl = UIFactory.table(model);
        tbl.getColumnModel().getColumn(5).setCellRenderer(new StatusRenderer());
        tbl.getColumnModel().getColumn(7).setCellRenderer(new RRActRenderer());
        tbl.getColumnModel().getColumn(7).setCellEditor(new RRActEditor(tbl, this));
        tbl.getColumnModel().getColumn(7).setPreferredWidth(130);
        tbl.setRowHeight(38);

        JPanel tc = UIFactory.tableCard();
        JPanel th = new JPanel(new BorderLayout()); th.setOpaque(false); th.setBorder(new EmptyBorder(0, 0, 8, 0));
        th.add(UIFactory.cardTitle("All Dormitory Rooms"), BorderLayout.WEST);
        tc.add(th, BorderLayout.NORTH);

        JPanel mid = new JPanel(new BorderLayout(0, 10)); mid.setOpaque(false);
        mid.add(UIFactory.info("Click 'Reserve' on an available room. Click 'Cancel' to free a booked room."), BorderLayout.NORTH);
        mid.add(tc, BorderLayout.CENTER);
        tc.add(UIFactory.scroll(tbl), BorderLayout.CENTER);
        add(mid, BorderLayout.CENTER);

        ctrl.loadRooms(this);
    }

    /** Called by controller to open the reservation dialog. */
    public void showReservationDialog(String roomNo, List<Student> students, ReservationCallback cb) {
        String[] names = students.stream()
            .map(s -> s.getFullName() + " [" + s.getStudentId() + "]")
            .toArray(String[]::new);

        if (names.length == 0) {
            JOptionPane.showMessageDialog(this,
                "No students registered. Please register a student first.",
                "No Students", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JDialog dlg = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this),
                                  "Reserve Room " + roomNo, true);
        dlg.setSize(440, 380); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE); form.setBorder(new EmptyBorder(18, 20, 18, 20));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 5, 6, 8); gc.fill = GridBagConstraints.HORIZONTAL;

        JComboBox<String> studCb = UIFactory.combo(names);
        JTextField dInFld  = UIFactory.field(); dInFld.setText("2025-06-01");
        JTextField dOutFld = UIFactory.field(); dOutFld.setText("2025-12-31");
        JTextField notesFld = UIFactory.field();

        UIFactory.gridSingle(form, gc, 0, "Student *",         studCb);
        UIFactory.gridSingle(form, gc, 1, "Date In (YYYY-MM-DD)", dInFld);
        UIFactory.gridSingle(form, gc, 2, "Date Out",           dOutFld);
        UIFactory.gridSingle(form, gc, 3, "Notes",              notesFld);

        JPanel br = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 12));
        br.setBackground(new Color(0xf0f4ff));
        br.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(0xc0c8e8)));

        JButton ok = AppTheme.makeBtn("Confirm Reservation", AppTheme.ACCENT);
        JButton cx = AppTheme.makeBtn("Cancel",              AppTheme.BTN_GRAY);
        ok.setPreferredSize(new Dimension(200, 38));
        cx.setPreferredSize(new Dimension(100, 38));

        cx.addActionListener(e -> dlg.dispose());
        ok.addActionListener(e -> {
            String choice = (String) studCb.getSelectedItem();
            if (choice == null) return;
            String sName = choice.substring(0, choice.lastIndexOf(" ["));
            String sId   = choice.substring(choice.lastIndexOf("[") + 1, choice.length() - 1);
            String dIn   = dInFld.getText().trim();
            String dOut  = dOutFld.getText().trim();
            if (dIn.isEmpty() || dOut.isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Please fill all required fields.", "Missing Input",
                                              JOptionPane.WARNING_MESSAGE);
                return;
            }
            dlg.dispose();
            cb.onConfirm(sName, sId, dIn, dOut, notesFld.getText().trim());
        });

        br.add(cx); br.add(ok);
        dlg.add(form, BorderLayout.CENTER); dlg.add(br, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    @FunctionalInterface
    public interface ReservationCallback {
        void onConfirm(String studentName, String studentId, String dateIn, String dateOut, String notes);
    }

    // ── Methods called by controller ──────────────────────────────────────
    public void populateTable(List<Room> rooms) {
        model.setRowCount(0);
        for (Room r : rooms)
            model.addRow(new Object[]{
                r.getRoomNo(), r.getRoomType(), r.getCapacity(), r.getFloorNo(),
                String.format("₱%,.0f", r.getMonthlyRate()),
                r.getStatus(), r.getReservedBy(), r.getStatus()
            });
        tbl.getColumnModel().getColumn(5).setCellRenderer(new StatusRenderer());
    }

    public void refresh()                       { ctrl.loadRooms(this); }
    public Object getTableValueAt(int r, int c) { return model.getValueAt(r, c); }
    public void showMessage(String msg, String title, int type) {
        JOptionPane.showMessageDialog(this, msg, title, type);
    }
    public int confirmDialog(String msg, String title) {
        return JOptionPane.showConfirmDialog(this, msg, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
    }
}

class RRActRenderer extends DefaultTableCellRenderer {
    public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int row, int col) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5)); p.setBackground(Color.WHITE);
        String st = (String) t.getValueAt(row, 5);
        p.add("Available".equals(st)
            ? AppTheme.makeSmallBtn("Reserve", AppTheme.ACCENT)
            : AppTheme.makeSmallBtn("Cancel",  AppTheme.S_BOOKED));
        return p;
    }
}

class RRActEditor extends DefaultCellEditor {
    private final RoomReservationView parent;
    RRActEditor(JTable t, RoomReservationView p) { super(new JCheckBox()); this.parent = p; }
    public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int row, int col) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5)); p.setBackground(Color.WHITE);
        String st = (String) t.getValueAt(row, 5);
        if ("Available".equals(st)) {
            JButton b = AppTheme.makeSmallBtn("Reserve", AppTheme.ACCENT);
            b.addActionListener(e -> { parent.ctrl.reserve(parent, row); stopCellEditing(); }); p.add(b);
        } else {
            JButton b = AppTheme.makeSmallBtn("Cancel", AppTheme.S_BOOKED);
            b.addActionListener(e -> { parent.ctrl.cancelReservation(parent, row); stopCellEditing(); }); p.add(b);
        }
        return p;
    }
    public Object getCellEditorValue() { return ""; }
}
