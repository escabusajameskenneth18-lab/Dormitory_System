package view;

import controller.MainController;
import controller.StudentController;
import model.Student;
import util.AppTheme;
import util.UIFactory;
import view.renderer.BtnRenderer;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * VIEW LAYER
 * Student Registration panel. Delegates all logic to StudentController.
 */
public class StudentView extends JPanel {

    StudentController ctrl;

    private JTextField idFld, nameFld, courseFld, emailFld, contactFld, addrFld, searchFld;
    private JComboBox<String> genderCb;
    private JLabel    fTitle;
    private JButton   saveBtn;
    private boolean   editMode = false;
    private DefaultTableModel model;
    private JTable    tbl;

    public StudentView(MainController mainCtrl) {
        ctrl = new StudentController(this, mainCtrl);
        setLayout(new BorderLayout(0, 14));
        setBackground(AppTheme.CONTENT_BG);
        setBorder(new EmptyBorder(22, 24, 22, 24));
        build();
    }

    private void build() {
        add(UIFactory.title("Student Registration"), BorderLayout.NORTH);

        // ── Form ─────────────────────────────────────────────────────────
        JPanel fc = UIFactory.formCard();
        fTitle = new JLabel("Register New Student");
        fTitle.setFont(new Font("Arial", Font.BOLD, 14));
        fTitle.setForeground(AppTheme.TEXT_DARK);
        fc.add(fTitle, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridBagLayout());
        grid.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 5, 5, 10); g.fill = GridBagConstraints.HORIZONTAL;

        idFld = UIFactory.field(); nameFld = UIFactory.field(); courseFld = UIFactory.field();
        emailFld = UIFactory.field(); contactFld = UIFactory.field(); addrFld = UIFactory.field();
        genderCb = UIFactory.combo("Male", "Female", "Other");

        UIFactory.gridRow(grid, g, 0, "Student ID *", idFld,      "Full Name *", nameFld);
        UIFactory.gridRow(grid, g, 1, "Course",        courseFld,  "Email",       emailFld);
        UIFactory.gridRow(grid, g, 2, "Contact No.",   contactFld, "Gender",      genderCb);
        UIFactory.gridWide(grid, g, 3, "Address",       addrFld);

        g.gridx = 0; g.gridy = 4; g.gridwidth = 1; g.weightx = 0.12;
        saveBtn = AppTheme.makeBtn("Save", AppTheme.ACCENT);
        saveBtn.addActionListener(e -> save());
        grid.add(saveBtn, g);

        g.gridx = 1; g.weightx = 0.12;
        JButton cx = AppTheme.makeBtn("Cancel", AppTheme.BTN_GRAY);
        cx.addActionListener(e -> clearForm());
        grid.add(cx, g);
        fc.add(grid, BorderLayout.CENTER);

        // ── Table ─────────────────────────────────────────────────────────
        JPanel tc = UIFactory.tableCard();
        JPanel th = new JPanel(new BorderLayout(8, 0));
        th.setOpaque(false); th.setBorder(new EmptyBorder(0, 0, 8, 0));
        th.add(UIFactory.cardTitle("Registered Students"), BorderLayout.WEST);

        searchFld = UIFactory.field();
        searchFld.setPreferredSize(new Dimension(200, 30));
        JButton sb = AppTheme.makeSmallBtn("Search", AppTheme.BTN_BLUE);
        JButton sc = AppTheme.makeSmallBtn("Clear",  AppTheme.BTN_GRAY);
        sb.addActionListener(e -> ctrl.search(searchFld.getText().trim()));
        sc.addActionListener(e -> { searchFld.setText(""); ctrl.loadAll(); });
        searchFld.addActionListener(e -> ctrl.search(searchFld.getText().trim()));
        JPanel sp = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        sp.setOpaque(false);
        sp.add(searchFld); sp.add(sb); sp.add(sc);
        th.add(sp, BorderLayout.EAST);
        tc.add(th, BorderLayout.NORTH);

        String[] cols = {"Student ID", "Full Name", "Course", "Email", "Contact", "Gender", "Actions"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return c == 6; }
        };
        tbl = UIFactory.table(model);
        tbl.getColumnModel().getColumn(6).setCellRenderer(
            new BtnRenderer(new String[]{"Edit", "Delete"}, new Color[]{AppTheme.ACCENT, AppTheme.S_BOOKED}));
        tbl.getColumnModel().getColumn(6).setCellEditor(new StudEditor(tbl, this));
        tbl.getColumnModel().getColumn(6).setPreferredWidth(160);
        tbl.setRowHeight(38);
        tc.add(UIFactory.scroll(tbl), BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout(0, 12));
        center.setOpaque(false);
        center.add(fc, BorderLayout.NORTH);
        center.add(tc, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        ctrl.loadAll();
    }

    private void save() {
        Student s = new Student(
            idFld.getText().trim(), nameFld.getText().trim(),
            courseFld.getText().trim(), emailFld.getText().trim(),
            contactFld.getText().trim(), (String) genderCb.getSelectedItem(),
            addrFld.getText().trim()
        );
        ctrl.save(s, editMode);
    }

    // ── Methods called by StudentController ───────────────────────────────
    public void populateTable(List<Student> students) {
        model.setRowCount(0);
        for (Student s : students)
            model.addRow(new Object[]{s.getStudentId(), s.getFullName(), s.getCourse(),
                s.getEmail(), s.getContact(), s.getGender(), "actions"});
    }

    public void fillFormForEdit(Student s) {
        editMode = true;
        idFld.setText(s.getStudentId()); idFld.setEditable(false); idFld.setBackground(new Color(0xf0f0f0));
        nameFld.setText(s.getFullName());   courseFld.setText(s.getCourse());
        emailFld.setText(s.getEmail());     contactFld.setText(s.getContact());
        genderCb.setSelectedItem(s.getGender()); addrFld.setText(s.getAddress());
        fTitle.setText("Editing: " + s.getFullName());
        saveBtn.setText("Update");
    }

    public void clearForm() {
        editMode = false;
        idFld.setText(""); idFld.setEditable(true); idFld.setBackground(Color.WHITE);
        nameFld.setText(""); courseFld.setText(""); emailFld.setText("");
        contactFld.setText(""); addrFld.setText(""); genderCb.setSelectedIndex(0);
        fTitle.setText("Register New Student"); saveBtn.setText("Save");
    }

    public void refresh()                      { ctrl.loadAll(); }
    public Object getTableValueAt(int r, int c){ return model.getValueAt(r, c); }
    public void showMessage(String msg, String title, int type) {
        JOptionPane.showMessageDialog(this, msg, title, type);
    }
    public int confirmDialog(String msg, String title) {
        return JOptionPane.showConfirmDialog(this, msg, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
    }
}

// ── Table cell editor with Edit/Delete buttons ────────────────────────────
class StudEditor extends DefaultCellEditor {
    private final StudentView parent;
    StudEditor(JTable t, StudentView p) { super(new JCheckBox()); this.parent = p; }
    public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int row, int col) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
        p.setBackground(Color.WHITE);
        JButton e = AppTheme.makeSmallBtn("Edit",   AppTheme.ACCENT);
        JButton d = AppTheme.makeSmallBtn("Delete", AppTheme.S_BOOKED);
        e.addActionListener(ev -> { parent.ctrl.startEdit(row); stopCellEditing(); });
        d.addActionListener(ev -> { parent.ctrl.delete(row);    stopCellEditing(); });
        p.add(e); p.add(d); return p;
    }
    public Object getCellEditorValue() { return "actions"; }
}
