package view;

import controller.ReservationController;
import model.Reservation;
import util.AppTheme;
import util.UIFactory;
import view.renderer.StatusRenderer;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * VIEW LAYER
 * Reservation Approval panel. Delegates all logic to ReservationController.
 */
public class ReservationApprovalView extends JPanel {

    private final ReservationController ctrl;
    private DefaultTableModel model;
    private JTable tbl;
    private JComboBox<String> filterCb;

    public ReservationApprovalView(ReservationController ctrl) {
        this.ctrl = ctrl;
        setLayout(new BorderLayout(0, 12));
        setBackground(AppTheme.CONTENT_BG);
        setBorder(new EmptyBorder(22, 24, 22, 24));
        build();
    }

    private void build() {
        add(UIFactory.title("Reservation Approval"), BorderLayout.NORTH);

        // Toolbar
        JPanel tb = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        tb.setBackground(Color.WHITE);
        tb.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0xe0e0e0), 1, true), new EmptyBorder(6, 10, 6, 10)));
        tb.add(UIFactory.lbl("Filter:"));
        filterCb = UIFactory.combo("All", "Pending", "Approved", "Rejected", "Cancelled", "Checked-In", "Checked-Out");
        filterCb.setPreferredSize(new Dimension(165, 32));
        filterCb.addActionListener(e -> ctrl.loadReservations(this, (String) filterCb.getSelectedItem()));
        tb.add(filterCb);
        JButton ref = AppTheme.makeSmallBtn("Refresh", AppTheme.BTN_BLUE);
        ref.addActionListener(e -> ctrl.loadReservations(this, (String) filterCb.getSelectedItem()));
        tb.add(ref);

        // Table
        String[] cols = {"Res. Code", "Student", "Std. ID", "Room", "Status", "Date In", "Date Out", "Created By", "Actions"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return c == 8; }
        };
        tbl = UIFactory.table(model);
        tbl.getColumnModel().getColumn(4).setCellRenderer(new StatusRenderer());
        tbl.getColumnModel().getColumn(8).setCellRenderer(new ApprActRenderer());
        tbl.getColumnModel().getColumn(8).setCellEditor(new ApprActEditor(tbl, this));
        tbl.getColumnModel().getColumn(8).setPreferredWidth(230);
        tbl.setRowHeight(40);

        JPanel tc = UIFactory.tableCard();
        JPanel th = new JPanel(new BorderLayout()); th.setOpaque(false); th.setBorder(new EmptyBorder(0, 0, 8, 0));
        th.add(UIFactory.cardTitle("All Reservations"), BorderLayout.WEST);
        tc.add(th, BorderLayout.NORTH); tc.add(UIFactory.scroll(tbl), BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout(0, 10)); center.setOpaque(false);
        center.add(tb, BorderLayout.NORTH); center.add(tc, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        ctrl.loadReservations(this, "All");
    }

    // ── Methods called by controller ─────────────────────────────────────
    public void populateTable(List<Reservation> list) {
        model.setRowCount(0);
        for (Reservation r : list)
            model.addRow(new Object[]{
                r.getResCode(), r.getStudentName(), r.getStudentIdRef(), r.getRoomNo(),
                r.getStatus(), r.getDateIn(), r.getDateOut(), r.getCreatedBy(), "actions"
            });
        tbl.getColumnModel().getColumn(4).setCellRenderer(new StatusRenderer());
        tbl.getColumnModel().getColumn(8).setCellRenderer(new ApprActRenderer());
    }

    public void refresh() {
        ctrl.loadReservations(this, filterCb != null ? (String) filterCb.getSelectedItem() : "All");
    }

    public Object getTableValueAt(int r, int c) { return model.getValueAt(r, c); }
    public void showMessage(String msg, String title, int type) {
        JOptionPane.showMessageDialog(this, msg, title, type);
    }
    public int confirmDialog(String msg, String title) {
        return JOptionPane.showConfirmDialog(this, msg, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
    }

    // ── Action delegation methods (called by editor) ───────────────────
    public void approve(int row)       { ctrl.approve(this, row); }
    public void reject(int row)        { ctrl.reject(this, row); }
    public void checkIn(int row)       { ctrl.checkIn(this, row); }
    public void checkOut(int row)      { ctrl.checkOut(this, row); }
    public void cancelApproval(int row){ ctrl.cancelApproval(this, row); }
    public void deleteRes(int row)     { ctrl.deleteReservation(this, row); }
}

class ApprActRenderer extends DefaultTableCellRenderer {
    public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int row, int col) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 4)); p.setBackground(Color.WHITE);
        String st = (String) t.getValueAt(row, 4);
        switch (st != null ? st : "") {
            case "Pending":
                p.add(AppTheme.makeSmallBtn("Approve", AppTheme.S_APPROVED));
                p.add(AppTheme.makeSmallBtn("Reject",  AppTheme.S_REJECTED)); break;
            case "Approved":
                p.add(AppTheme.makeSmallBtn("Check In", AppTheme.BTN_BLUE));
                p.add(AppTheme.makeSmallBtn("Cancel",   AppTheme.BTN_GRAY)); break;
            case "Checked-In":
                p.add(AppTheme.makeSmallBtn("Check Out", AppTheme.BTN_ORANGE)); break;
            default:
                p.add(AppTheme.makeSmallBtn("Delete", AppTheme.BTN_GRAY));
        }
        return p;
    }
}

class ApprActEditor extends DefaultCellEditor {
    private final ReservationApprovalView parent;
    ApprActEditor(JTable t, ReservationApprovalView p) { super(new JCheckBox()); this.parent = p; }
    public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int row, int col) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 4)); p.setBackground(Color.WHITE);
        String st = (String) t.getValueAt(row, 4);
        switch (st != null ? st : "") {
            case "Pending":
                JButton ap = AppTheme.makeSmallBtn("Approve", AppTheme.S_APPROVED);
                JButton rj = AppTheme.makeSmallBtn("Reject",  AppTheme.S_REJECTED);
                ap.addActionListener(e -> { parent.approve(row); stopCellEditing(); });
                rj.addActionListener(e -> { parent.reject(row);  stopCellEditing(); });
                p.add(ap); p.add(rj); break;
            case "Approved":
                JButton ci = AppTheme.makeSmallBtn("Check In", AppTheme.BTN_BLUE);
                JButton cx = AppTheme.makeSmallBtn("Cancel",   AppTheme.BTN_GRAY);
                ci.addActionListener(e -> { parent.checkIn(row);       stopCellEditing(); });
                cx.addActionListener(e -> { parent.cancelApproval(row); stopCellEditing(); });
                p.add(ci); p.add(cx); break;
            case "Checked-In":
                JButton co = AppTheme.makeSmallBtn("Check Out", AppTheme.BTN_ORANGE);
                co.addActionListener(e -> { parent.checkOut(row); stopCellEditing(); }); p.add(co); break;
            default:
                JButton dl = AppTheme.makeSmallBtn("Delete", AppTheme.BTN_GRAY);
                dl.addActionListener(e -> { parent.deleteRes(row); stopCellEditing(); }); p.add(dl);
        }
        return p;
    }
    public Object getCellEditorValue() { return "actions"; }
}
