package view;

import controller.LoginController;
import util.AppTheme;
import util.UIFactory;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * VIEW LAYER
 * The login screen. Delegates all logic to LoginController.
 */
public class LoginView extends JFrame {

    private JTextField     userFld;
    private JPasswordField passFld;
    private JLabel         statusLbl;
    private JButton        loginBtn;

    private LoginController controller;

    public LoginView() {
        controller = new LoginController(this);
        setTitle("Dormitory Reservation Management System — Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(460, 560);
        setLocationRelativeTo(null);
        setResizable(false);
        build();
        setVisible(true);
    }

    private void build() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(AppTheme.CONTENT_BG);

        // Banner
        JPanel banner = new JPanel(new BorderLayout());
        banner.setBackground(AppTheme.HEADER_BG);
        banner.setPreferredSize(new Dimension(0, 90));
        JLabel bl = new JLabel(
            "<html><center>Dormitory Reservation<br>Management System</center></html>",
            SwingConstants.CENTER);
        bl.setFont(new Font("Arial", Font.BOLD, 19));
        bl.setForeground(Color.WHITE);
        banner.add(bl, BorderLayout.CENTER);
        root.add(banner, BorderLayout.NORTH);

        // Card
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0xe0e0e0), 1, true),
            new EmptyBorder(28, 40, 28, 40)));

        JLabel welcome = new JLabel("Welcome Back", SwingConstants.CENTER);
        welcome.setFont(new Font("Arial", Font.BOLD, 22));
        welcome.setForeground(AppTheme.TEXT_DARK);
        welcome.setAlignmentX(CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Sign in to continue", SwingConstants.CENTER);
        sub.setFont(AppTheme.F_SMALL);
        sub.setForeground(Color.GRAY);
        sub.setAlignmentX(CENTER_ALIGNMENT);

        JLabel userLbl = UIFactory.lbl("Username");
        userLbl.setAlignmentX(LEFT_ALIGNMENT);
        userFld = UIFactory.field();
        userFld.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        userFld.setAlignmentX(CENTER_ALIGNMENT);

        JLabel passLbl = UIFactory.lbl("Password");
        passLbl.setAlignmentX(LEFT_ALIGNMENT);
        passFld = UIFactory.pass();
        passFld.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        passFld.setAlignmentX(CENTER_ALIGNMENT);
        passFld.addActionListener(e -> doLogin());

        statusLbl = new JLabel(" ", SwingConstants.LEFT);
        statusLbl.setFont(AppTheme.F_SMALL);
        statusLbl.setForeground(AppTheme.S_BOOKED);
        statusLbl.setAlignmentX(LEFT_ALIGNMENT);

        loginBtn = AppTheme.makeBtn("Login", AppTheme.ACCENT);
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        loginBtn.setAlignmentX(CENTER_ALIGNMENT);
        loginBtn.addActionListener(e -> doLogin());

        JLabel hint = new JLabel("Default: admin / admin123", SwingConstants.LEFT);
        hint.setFont(AppTheme.F_ITALIC);
        hint.setForeground(new Color(0xbbbbbb));
        hint.setAlignmentX(LEFT_ALIGNMENT);

        card.add(Box.createVerticalStrut(4));
        card.add(welcome);
        card.add(Box.createVerticalStrut(4));
        card.add(sub);
        card.add(Box.createVerticalStrut(24));
        card.add(userLbl);
        card.add(Box.createVerticalStrut(5));
        card.add(userFld);
        card.add(Box.createVerticalStrut(14));
        card.add(passLbl);
        card.add(Box.createVerticalStrut(5));
        card.add(passFld);
        card.add(Box.createVerticalStrut(6));
        card.add(statusLbl);
        card.add(Box.createVerticalStrut(10));
        card.add(loginBtn);
        card.add(Box.createVerticalStrut(10));
        card.add(hint);

        JPanel mid = new JPanel(new GridBagLayout());
        mid.setBackground(AppTheme.CONTENT_BG);
        mid.add(card, new GridBagConstraints());
        root.add(mid, BorderLayout.CENTER);

        // Footer
        JPanel foot = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 7));
        foot.setBackground(AppTheme.HEADER_BG);
        foot.setPreferredSize(new Dimension(0, 32));
        JLabel fl = new JLabel("© 2025 Dormitory Management System  |  Powered by MySQL");
        fl.setFont(AppTheme.F_SMALL);
        fl.setForeground(new Color(0x888888));
        foot.add(fl);
        root.add(foot, BorderLayout.SOUTH);

        setContentPane(root);
    }

    private void doLogin() {
        controller.handleLogin(userFld.getText().trim(), new String(passFld.getPassword()));
    }

    // ── Methods called by LoginController ─────────────────────────────────
    public void showStatus(String msg)  { statusLbl.setText(msg); }
    public void clearPassword()         { passFld.setText(""); }
    public void setLoading(boolean on)  {
        loginBtn.setEnabled(!on);
        loginBtn.setText(on ? "Signing in..." : "Login");
    }
}
