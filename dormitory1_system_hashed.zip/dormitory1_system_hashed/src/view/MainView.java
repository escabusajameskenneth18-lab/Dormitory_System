package view;

import controller.MainController;
import controller.ReservationController;
import model.Session;
import util.AppTheme;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * VIEW LAYER
 * The main application window. Holds the sidebar and CardLayout content area.
 * Uses MainController to coordinate refreshes across all panels.
 */
public class MainView extends JFrame {

    private JPanel     content;
    private CardLayout cards;
    private final Map<String, JButton> navBtns = new LinkedHashMap<>();

    // Panel references (needed for refresh)
    private DashboardView         dashView;
    private StudentView           studView;
    private RoomReservationView   roomResView;
    private ManageRoomsView       manageRoomsView;
    private ReservationApprovalView approvalView;
    private ReportsView           reportsView;

    private final MainController mainCtrl = new MainController();

    public MainView() {
        mainCtrl.setView(this);
        setTitle("Dormitory Reservation Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 760);
        setMinimumSize(new Dimension(1000, 640));
        setLocationRelativeTo(null);
        build();
        setVisible(true);
    }

    private void build() {
        setLayout(new BorderLayout());

        // ── Header ───────────────────────────────────────────────────────
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(AppTheme.HEADER_BG);
        hdr.setPreferredSize(new Dimension(0, 58));
        hdr.setBorder(new EmptyBorder(0, 20, 0, 20));

        JLabel titleLbl = new JLabel("Dormitory Reservation Management System");
        titleLbl.setFont(AppTheme.F_HEADER);
        titleLbl.setForeground(Color.WHITE);
        hdr.add(titleLbl, BorderLayout.WEST);

        JPanel rh = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 14));
        rh.setOpaque(false);
        JLabel uLbl = new JLabel("\ud83d\udc64  " + Session.getName() + "  [" + Session.getRole() + "]");
        uLbl.setFont(new Font("Arial", Font.PLAIN, 12));
        uLbl.setForeground(new Color(0xaaffee));
        rh.add(uLbl);

        JButton logoutBtn = AppTheme.makeSmallBtn("Logout", AppTheme.BTN_RED);
        logoutBtn.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(this, "Logout?", "Confirm",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                Session.clear();
                dispose();
                new LoginView();
            }
        });
        rh.add(logoutBtn);
        hdr.add(rh, BorderLayout.EAST);
        add(hdr, BorderLayout.NORTH);

        // ── Sidebar ──────────────────────────────────────────────────────
        add(buildSidebar(), BorderLayout.WEST);

        // ── Content panels ───────────────────────────────────────────────
        cards   = new CardLayout();
        content = new JPanel(cards);
        content.setBackground(AppTheme.CONTENT_BG);

        ReservationController resCtrl = new ReservationController(mainCtrl);

        dashView        = new DashboardView(mainCtrl);
        studView        = new StudentView(mainCtrl);
        roomResView     = new RoomReservationView(resCtrl);
        manageRoomsView = new ManageRoomsView(mainCtrl);
        approvalView    = new ReservationApprovalView(resCtrl);
        reportsView     = new ReportsView();

        content.add(dashView,        "dashboard");
        content.add(studView,        "students");
        content.add(roomResView,     "room-res");
        content.add(manageRoomsView, "manage-rooms");
        content.add(approvalView,    "approval");
        content.add(reportsView,     "reports");

        add(content, BorderLayout.CENTER);
        show("dashboard");
    }

    private JPanel buildSidebar() {
        JPanel sb = new JPanel();
        sb.setLayout(new BoxLayout(sb, BoxLayout.Y_AXIS));
        sb.setBackground(AppTheme.SIDEBAR_BG);
        sb.setPreferredSize(new Dimension(230, 0));
        sb.setBorder(new EmptyBorder(6, 0, 10, 0));

        JLabel nav = new JLabel("  MAIN MENU");
        nav.setFont(new Font("Arial", Font.BOLD, 10));
        nav.setForeground(new Color(0x7f8c8d));
        nav.setMaximumSize(new Dimension(230, 26));
        nav.setBorder(new EmptyBorder(8, 14, 4, 0));
        sb.add(nav);

        String[][] items = {
            {"dashboard",    "\ud83d\udcca   Dashboard"},
            {"students",     "\ud83c\udf93   Student Registration"},
            {"room-res",     "\ud83d\udecf   Room Reservation"},
            {"manage-rooms", "\ud83d\udd11   Manage Rooms"},
            {"approval",     "\u2705   Reservation Approval"},
            {"reports",      "\ud83d\udcc4   Generate Reports"},
        };
        for (String[] it : items) {
            JButton b = navBtn(it[1], it[0]);
            navBtns.put(it[0], b);
            sb.add(b);
        }
        sb.add(Box.createVerticalGlue());

        JLabel dbLbl = new JLabel("  MySQL: dorm_db");
        dbLbl.setFont(AppTheme.F_ITALIC);
        dbLbl.setForeground(new Color(0x5d6d7e));
        dbLbl.setMaximumSize(new Dimension(230, 24));
        sb.add(dbLbl);
        return sb;
    }

    private JButton navBtn(String label, String key) {
        JButton b = new JButton(label);
        b.setFont(AppTheme.F_SIDEBAR);
        b.setForeground(Color.WHITE);
        b.setBackground(AppTheme.SIDEBAR_BG);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setMaximumSize(new Dimension(230, 55));
        b.setPreferredSize(new Dimension(230, 55));
        b.setBorder(new EmptyBorder(5, 18, 5, 0));
        Color hover = new Color(0x3d566e);
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!b.getBackground().equals(AppTheme.ACCENT)) b.setBackground(hover);
            }
            public void mouseExited(MouseEvent e) {
                if (!b.getBackground().equals(AppTheme.ACCENT)) b.setBackground(AppTheme.SIDEBAR_BG);
            }
        });
        b.addActionListener(e -> show(key));
        return b;
    }

    public void show(String key) {
        switch (key) {
            case "dashboard":    if (dashView    != null) dashView.refresh();    break;
            case "students":     if (studView    != null) studView.refresh();    break;
            case "room-res":     if (roomResView != null) roomResView.refresh(); break;
            case "manage-rooms": if (manageRoomsView != null) manageRoomsView.refresh(); break;
            case "approval":     if (approvalView != null) approvalView.refresh(); break;
        }
        cards.show(content, key);
        navBtns.forEach((k, btn) ->
            btn.setBackground(k.equals(key) ? AppTheme.ACCENT : AppTheme.SIDEBAR_BG));
    }

    /** Called by MainController after any data change. */
    public void refreshAllPanels() {
        if (dashView        != null) dashView.refresh();
        if (studView        != null) studView.refresh();
        if (roomResView     != null) roomResView.refresh();
        if (manageRoomsView != null) manageRoomsView.refresh();
        if (approvalView    != null) approvalView.refresh();
    }
}
