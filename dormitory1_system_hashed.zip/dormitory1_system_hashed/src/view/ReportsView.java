package view;

import model.DBConnection;
import util.AppTheme;
import util.UIFactory;
import view.renderer.StatusRenderer;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.print.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * VIEW LAYER
 * Reports panel. Directly queries DB for display-only reporting purposes.
 * No data modification occurs here — pure read-only display.
 */
public class ReportsView extends JPanel {

    private JComboBox<String> typeCb;
    private DefaultTableModel model;
    private JTable tbl;
    private JLabel titleLbl, genLbl, cntLbl;

    public ReportsView() {
        setLayout(new BorderLayout(0, 14));
        setBackground(AppTheme.CONTENT_BG);
        setBorder(new EmptyBorder(22, 24, 22, 24));
        build();
    }

    private void build() {
        add(UIFactory.title("Generate Reports"), BorderLayout.NORTH);

        JPanel tb = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        tb.setBackground(Color.WHITE);
        tb.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0xe0e0e0), 1, true), new EmptyBorder(10, 12, 10, 12)));

        tb.add(UIFactory.lbl("Report Type:"));
        typeCb = UIFactory.combo(
            "Student Report", "Room Status Report", "All Reservations",
            "Pending Reservations", "Approved Reservations",
            "Checked-In Students", "Available Rooms", "Reservation History");
        typeCb.setPreferredSize(new Dimension(230, 36));
        tb.add(typeCb);

        JButton gen    = AppTheme.makeBtn("Generate",   AppTheme.ACCENT);
        JButton print  = AppTheme.makeBtn("Print",      AppTheme.BTN_BLUE);
        JButton export = AppTheme.makeBtn("Export CSV", AppTheme.BTN_GREEN);
        for (JButton b : new JButton[]{gen, print, export})
            b.setPreferredSize(new Dimension(140, 36));
        gen.addActionListener(e -> generate());
        print.addActionListener(e -> doPrint());
        export.addActionListener(e -> doExport());
        tb.add(gen); tb.add(print); tb.add(export);

        JPanel rc = UIFactory.tableCard();
        JPanel rh = new JPanel(new BorderLayout(8, 0));
        rh.setOpaque(false); rh.setBorder(new EmptyBorder(0, 0, 8, 0));
        titleLbl = new JLabel("Select a report type and click Generate.");
        titleLbl.setFont(new Font("Arial", Font.BOLD, 14));
        titleLbl.setForeground(AppTheme.TEXT_DARK);
        rh.add(titleLbl, BorderLayout.WEST);

        JPanel ri = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); ri.setOpaque(false);
        cntLbl = new JLabel(""); cntLbl.setFont(AppTheme.F_BOLD); cntLbl.setForeground(AppTheme.ACCENT);
        genLbl = new JLabel(""); genLbl.setFont(AppTheme.F_ITALIC); genLbl.setForeground(Color.GRAY);
        ri.add(cntLbl); ri.add(genLbl);
        rh.add(ri, BorderLayout.EAST);
        rc.add(rh, BorderLayout.NORTH);

        model = new DefaultTableModel();
        tbl = UIFactory.table(model);
        rc.add(UIFactory.scroll(tbl), BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout(0, 10)); center.setOpaque(false);
        center.add(tb, BorderLayout.NORTH); center.add(rc, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
    }

    private void generate() {
        model.setRowCount(0); model.setColumnCount(0);
        String type = (String) typeCb.getSelectedItem();
        String ts   = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            String sql = ""; String[] cols = {};
            switch (type) {
                case "Student Report":
                    cols = new String[]{"Student ID","Full Name","Course","Email","Contact","Gender","Registered"};
                    sql  = "SELECT student_id,full_name,IFNULL(course,''),IFNULL(email,''),IFNULL(contact,''),"
                         + "IFNULL(gender,''),DATE_FORMAT(created_at,'%Y-%m-%d') FROM students ORDER BY full_name";
                    break;
                case "Room Status Report":
                    cols = new String[]{"Room No.","Type","Capacity","Floor","Rate/mo","Status","Reserved By"};
                    sql  = "SELECT room_no,room_type,capacity,floor_no,"
                         + "CONCAT('\u20b1',FORMAT(monthly_rate,0)),status,IFNULL(reserved_by,'') FROM rooms ORDER BY floor_no,room_no";
                    break;
                case "All Reservations":
                    cols = new String[]{"Res. Code","Student","Std. ID","Room","Status","Date In","Date Out","Created"};
                    sql  = "SELECT res_code,student_name,student_id_ref,room_no,status,"
                         + "IFNULL(DATE_FORMAT(date_in,'%Y-%m-%d'),''),IFNULL(DATE_FORMAT(date_out,'%Y-%m-%d'),''),"
                         + "DATE_FORMAT(created_at,'%Y-%m-%d %H:%i') FROM reservations ORDER BY created_at DESC";
                    break;
                case "Pending Reservations":
                    cols = new String[]{"Res. Code","Student","Std. ID","Room","Status","Date In","Date Out","Created"};
                    sql  = "SELECT res_code,student_name,student_id_ref,room_no,status,"
                         + "IFNULL(DATE_FORMAT(date_in,'%Y-%m-%d'),''),IFNULL(DATE_FORMAT(date_out,'%Y-%m-%d'),''),"
                         + "DATE_FORMAT(created_at,'%Y-%m-%d %H:%i') FROM reservations WHERE status='Pending' ORDER BY created_at DESC";
                    break;
                case "Approved Reservations":
                    cols = new String[]{"Res. Code","Student","Std. ID","Room","Status","Date In","Date Out","Created"};
                    sql  = "SELECT res_code,student_name,student_id_ref,room_no,status,"
                         + "IFNULL(DATE_FORMAT(date_in,'%Y-%m-%d'),''),IFNULL(DATE_FORMAT(date_out,'%Y-%m-%d'),''),"
                         + "DATE_FORMAT(created_at,'%Y-%m-%d %H:%i') FROM reservations WHERE status='Approved' ORDER BY created_at";
                    break;
                case "Checked-In Students":
                    cols = new String[]{"Res. Code","Student","Std. ID","Room","Date In","Date Out","Created"};
                    sql  = "SELECT res_code,student_name,student_id_ref,room_no,"
                         + "IFNULL(DATE_FORMAT(date_in,'%Y-%m-%d'),''),IFNULL(DATE_FORMAT(date_out,'%Y-%m-%d'),''),"
                         + "DATE_FORMAT(created_at,'%Y-%m-%d %H:%i') FROM reservations WHERE status='Checked-In' ORDER BY student_name";
                    break;
                case "Available Rooms":
                    cols = new String[]{"Room No.","Type","Capacity","Floor","Rate/mo"};
                    sql  = "SELECT room_no,room_type,capacity,floor_no,CONCAT('\u20b1',FORMAT(monthly_rate,0)) "
                         + "FROM rooms WHERE status='Available' ORDER BY floor_no,room_no";
                    break;
                case "Reservation History":
                    cols = new String[]{"Res. Code","Student","Room","Status","Date In","Date Out","Created","Updated"};
                    sql  = "SELECT res_code,student_name,room_no,status,"
                         + "IFNULL(DATE_FORMAT(date_in,'%Y-%m-%d'),''),IFNULL(DATE_FORMAT(date_out,'%Y-%m-%d'),''),"
                         + "DATE_FORMAT(created_at,'%Y-%m-%d %H:%i'),DATE_FORMAT(updated_at,'%Y-%m-%d %H:%i') "
                         + "FROM reservations ORDER BY updated_at DESC";
                    break;
            }
            model.setColumnIdentifiers(cols);
            ps = DBConnection.get().prepareStatement(sql); rs = ps.executeQuery();
            int nc = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                Object[] row = new Object[nc];
                for (int i = 0; i < nc; i++) row[i] = rs.getObject(i + 1);
                model.addRow(row);
            }
            // Re-apply renderers
            DefaultTableCellRenderer cr = new DefaultTableCellRenderer();
            cr.setHorizontalAlignment(SwingConstants.CENTER);
            for (int i = 0; i < tbl.getColumnCount(); i++)
                tbl.getColumnModel().getColumn(i).setCellRenderer(cr);
            for (int i = 0; i < cols.length; i++)
                if ("Status".equals(cols[i]))
                    tbl.getColumnModel().getColumn(i).setCellRenderer(new StatusRenderer());

            titleLbl.setText(type);
            genLbl.setText("  Generated: " + ts);
            cntLbl.setText(model.getRowCount() + " record(s)");
            JOptionPane.showMessageDialog(this, type + " generated!\n" + model.getRowCount() + " record(s) found.",
                "Generated", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally { DBConnection.close(rs, ps); }
    }

    private void doPrint() {
        if (model.getRowCount() == 0) { JOptionPane.showMessageDialog(this, "Generate a report first.", "No Data", JOptionPane.WARNING_MESSAGE); return; }
        try { tbl.print(JTable.PrintMode.FIT_WIDTH,
            new java.text.MessageFormat("Dormitory Reservation Management System — " + titleLbl.getText()),
            new java.text.MessageFormat("Page {0}  |  " + genLbl.getText()));
        } catch (PrinterException ex) { JOptionPane.showMessageDialog(this, "Print error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void doExport() {
        if (model.getRowCount() == 0) { JOptionPane.showMessageDialog(this, "Generate a report first.", "No Data", JOptionPane.WARNING_MESSAGE); return; }
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new java.io.File(titleLbl.getText().replaceAll("[^a-zA-Z0-9]", "_") + ".csv"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (java.io.PrintWriter pw = new java.io.PrintWriter(fc.getSelectedFile())) {
            StringBuilder sb = new StringBuilder();
            for (int c = 0; c < model.getColumnCount(); c++) { if (c > 0) sb.append(","); sb.append("\"").append(model.getColumnName(c)).append("\""); }
            pw.println(sb);
            for (int r = 0; r < model.getRowCount(); r++) {
                sb = new StringBuilder();
                for (int c = 0; c < model.getColumnCount(); c++) {
                    if (c > 0) sb.append(",");
                    Object v = model.getValueAt(r, c);
                    sb.append("\"").append(v == null ? "" : v.toString().replace("\"", "''")).append("\"");
                }
                pw.println(sb);
            }
            JOptionPane.showMessageDialog(this, "Exported to:\n" + fc.getSelectedFile().getAbsolutePath(), "Exported", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Export error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }
}
