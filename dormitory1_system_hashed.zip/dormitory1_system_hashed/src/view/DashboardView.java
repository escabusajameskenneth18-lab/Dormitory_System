package view;

import controller.MainController;
import model.dao.ReservationDAO;
import model.Reservation;
import util.AppTheme;
import util.UIFactory;
import view.renderer.StatusRenderer;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import model.DBConnection;

/**
 * VIEW LAYER
 * Dashboard panel — shows live stats and recent reservations.
 * All data is loaded via MainController → DAOs.
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


    

public class DashboardView extends JPanel {

    private final MainController ctrl;
    private JLabel totalRoomsVal, availVal, bookedVal,maintenanceVal, pendingVal, studVal;
    private DefaultTableModel recentModel;
    private JTable recentTbl;

    public DashboardView(MainController ctrl) {
        this.ctrl = ctrl;
        setLayout(new BorderLayout(0, 16));
        setBackground(AppTheme.CONTENT_BG);
        setBorder(new EmptyBorder(22, 24, 22, 24));
        build();
    }

    private void build() {
        add(UIFactory.title("Dashboard — Overview"), BorderLayout.NORTH);

        // ── Stat cards (2 rows x 3 cols) ─────────────────────────────────
        JPanel row1 = new JPanel(new GridLayout(2, 3, 16, 16));
        row1.setOpaque(false);
        totalRoomsVal   = addCard(row1, CardIcon.HOUSE,   "Total Rooms",       "0", AppTheme.TEXT_DARK);
        availVal   = addCard(row1, CardIcon.CHECK,   "Available",         "0", AppTheme.S_AVAILABLE);
        bookedVal  = addCard(row1, CardIcon.BED,     "Booked",            "0", AppTheme.S_BOOKED);
        maintenanceVal   = addCard(row1, CardIcon.WRENCH,  "Maintenance",       "0", AppTheme.S_MAINTENANCE);
        pendingVal = addCard(row1, CardIcon.CLOCK,   "Pending Approvals", "0", AppTheme.S_PENDING);
        studVal    = addCard(row1, CardIcon.GRAD,    "Students",          "0", AppTheme.BTN_BLUE);

        // ── Quick actions ─────────────────────────────────────────────────
        JPanel qa = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        qa.setOpaque(false);
        JLabel ql = new JLabel("Quick Actions:");
        ql.setFont(AppTheme.F_BOLD);
        ql.setForeground(AppTheme.TEXT_DARK);
        qa.add(ql);

        JButton b1 = makeQBtn("Reserve Room", BtnIcon.BED,     AppTheme.ACCENT);
        JButton b2 = makeQBtn("Approvals",    BtnIcon.SHIELD,  AppTheme.S_PENDING);
        JButton b3 = makeQBtn("Add Student",  BtnIcon.PERSON,  AppTheme.BTN_BLUE);
        JButton b4 = makeQBtn("Add Room",     BtnIcon.PLUS,    AppTheme.BTN_PURPLE);
        JButton b5 = makeQBtn("Reports",      BtnIcon.DOC,     AppTheme.BTN_ORANGE);

        b1.addActionListener(e -> ctrl.show("room-res"));
        b2.addActionListener(e -> ctrl.show("approval"));
        b3.addActionListener(e -> ctrl.show("students"));
        b4.addActionListener(e -> ctrl.show("manage-rooms"));
        b5.addActionListener(e -> ctrl.show("reports"));

        qa.add(b1); qa.add(b2); qa.add(b3); qa.add(b4); qa.add(b5);

        // ── Recent reservations ───────────────────────────────────────────
        String[] cols = {"Res. Code","Student","Student ID","Room","Status","Date In","Date Out","Created"};
        recentModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        recentTbl = UIFactory.table(recentModel);
        recentTbl.getColumnModel().getColumn(4).setCellRenderer(new StatusRenderer());

        JPanel tCard = UIFactory.tableCard();
        JPanel tHdr  = new JPanel(new BorderLayout());
        tHdr.setOpaque(false);
        tHdr.setBorder(new EmptyBorder(0, 0, 8, 0));
        tHdr.add(UIFactory.cardTitle("Recent Reservations"), BorderLayout.WEST);
        JButton va = AppTheme.makeSmallBtn("View All →", AppTheme.ACCENT);
        va.addActionListener(e -> ctrl.show("approval"));
        tHdr.add(va, BorderLayout.EAST);
        tCard.add(tHdr,              BorderLayout.NORTH);
        tCard.add(UIFactory.scroll(recentTbl), BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout(0, 12));
        center.setOpaque(false);
        center.add(row1, BorderLayout.NORTH);

        JPanel mid = new JPanel(new BorderLayout(0, 10));
        mid.setOpaque(false);
        mid.add(qa,    BorderLayout.NORTH);
        mid.add(tCard, BorderLayout.CENTER);
        center.add(mid, BorderLayout.CENTER);

        add(center, BorderLayout.CENTER);
        refresh();
    }

    // ── Stat card with painted icon ───────────────────────────────────────
    private JLabel addCard(JPanel p, CardIcon icon, String title, String val, Color color) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0xe0e0e0), 1, true),
            new EmptyBorder(18, 12, 18, 12)));

        // Painted icon — guaranteed full render, no emoji box problem
        JPanel iconPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g0) {
                super.paintComponent(g0);
                Graphics2D g = (Graphics2D) g0.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
                int s = 36;
                int cx = (getWidth() - s) / 2;
                int cy = (getHeight() - s) / 2;
                // Soft tinted circle backdrop
                g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 22));
                g.fillOval(cx - 6, cy - 6, s + 12, s + 12);
                g.setColor(color);
                drawCardIcon(g, icon, cx, cy, s);
                g.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(56, 56); }
        };
        iconPanel.setOpaque(false);

        JLabel tl = new JLabel(title, SwingConstants.CENTER);
        tl.setFont(new Font("Arial", Font.BOLD, 11));
        tl.setForeground(new Color(0x666666));

        JLabel vl = new JLabel(val, SwingConstants.CENTER);
        vl.setFont(new Font("Arial", Font.BOLD, 34));
        vl.setForeground(color);

        JPanel top = new JPanel(new BorderLayout(0, 2));
        top.setOpaque(false);
        top.add(iconPanel, BorderLayout.CENTER);
        top.add(tl,        BorderLayout.SOUTH);

        card.add(top, BorderLayout.NORTH);
        card.add(vl,  BorderLayout.CENTER);
        p.add(card);
        return vl;
    }

    // ── Quick-action button with painted icon ─────────────────────────────
    private JButton makeQBtn(String label, BtnIcon icon, Color bg) {
        JButton btn = new JButton(label) {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth(), h = getHeight();
                g.setColor(getModel().isPressed()  ? bg.darker()   :
                           getModel().isRollover() ? bg.brighter() : bg);
                g.fillRoundRect(0, 0, w, h, 10, 10);
                // Draw icon at left
                g.setColor(Color.WHITE);
                drawBtnIcon(g, icon, 10, (h - 16) / 2, 16, 16);
                // Draw label
                g.setFont(getFont());
                FontMetrics fm = g.getFontMetrics();
                g.drawString(getText(), 32, (h + fm.getAscent() - fm.getDescent()) / 2);
                g.dispose();
            }
        };
        btn.setPreferredSize(new Dimension(145, 36));
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // ── Card icon shapes ──────────────────────────────────────────────────
    enum CardIcon { HOUSE, CHECK, BED, WRENCH, CLOCK, GRAD }
    enum BtnIcon  { BED, SHIELD, PERSON, PLUS, DOC }

    private void drawCardIcon(Graphics2D g, CardIcon icon, int x, int y, int s) {
        Stroke def = g.getStroke();
        switch (icon) {
            case HOUSE: {
                // Roof
                int cx = x + s / 2;
                int[] rx = {x, cx, x + s};
                int[] ry = {y + s / 2, y, y + s / 2};
                g.fillPolygon(rx, ry, 3);
                // Body
                g.fillRoundRect(x + 4, y + s / 2, s - 8, s / 2, 3, 3);
                // Door
                g.setColor(new Color(255, 255, 255, 180));
                g.fillRect(cx - 4, y + s * 3 / 4, 8, s / 4);
                break;
            }
            case CHECK: {
                // Rounded square background
                g.fillRoundRect(x, y + 2, s, s - 4, 8, 8);
                g.setColor(Color.WHITE);
                g.setStroke(new BasicStroke(3.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(x + 6, y + s / 2, x + s * 2 / 5, y + s - 8);
                g.drawLine(x + s * 2 / 5, y + s - 8, x + s - 6, y + 8);
                g.setStroke(def);
                break;
            }
            case BED: {
                // Bed base
                g.fillRoundRect(x, y + s / 2, s, s / 2, 5, 5);
                // Pillow
                g.fillRoundRect(x + 4, y + s / 3, s / 2 - 6, s / 4, 4, 4);
                // Headboard
                g.fillRoundRect(x, y + s / 4, 6, s * 3 / 4, 3, 3);
                // Legs
                g.fillRect(x + 3,     y + s - 4, 4, 4);
                g.fillRect(x + s - 7, y + s - 4, 4, 4);
                break;
            }
            case WRENCH: {
                g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                // Handle
                g.drawLine(x + 8, y + s - 8, x + s - 4, y + 6);
                g.setStroke(def);
                // Circle head
                g.fillOval(x + s - 12, y, 12, 12);
                g.setColor(new Color(255,255,255,150));
                g.fillOval(x + s - 10, y + 2, 8, 8);
                g.setColor(g.getColor()); // reset — caller sets color
                break;
            }
            case CLOCK: {
                // Face
                g.fillOval(x, y, s, s);
                g.setColor(new Color(255, 255, 255, 60));
                g.fillOval(x + 3, y + 3, s - 6, s - 6);
                // Hands
                g.setColor(Color.WHITE);
                g.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                int cx = x + s / 2, cy = y + s / 2;
                g.drawLine(cx, cy, cx, cy - s / 3);          // hour
                g.drawLine(cx, cy, cx + s / 4, cy);          // minute
                g.setStroke(def);
                g.fillOval(cx - 3, cy - 3, 6, 6);
                break;
            }
            case GRAD: {
                int cx = x + s / 2;
                // Cap top (diamond)
                int[] hx = {cx, x + s, cx, x};
                int[] hy = {y + 4, y + s / 3, y + s / 2, y + s / 3};
                g.fillPolygon(hx, hy, 4);
                // Head below cap
                g.fillOval(cx - s / 6, y + s / 3, s / 3, s / 3);
                // Tassel
                g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(x + s - 4, y + s / 3, x + s - 4, y + s * 2 / 3);
                g.setStroke(def);
                g.fillOval(x + s - 7, y + s * 2 / 3, 6, 6);
                break;
            }
        }
    }

    private void drawBtnIcon(Graphics2D g, BtnIcon icon, int x, int y, int w, int h) {
        Stroke def = g.getStroke();
        switch (icon) {
            case BED: {
                g.fillRoundRect(x, y + h / 2, w, h / 2, 4, 4);
                g.fillRoundRect(x + 2, y + h / 3, w / 2 - 4, h / 4, 3, 3);
                g.fillRoundRect(x, y + h / 4, 4, h * 3 / 4, 2, 2);
                break;
            }
            case SHIELD: {
                int cx = x + w / 2;
                int[] sx = {x, x, cx, x + w, x + w};
                int[] sy = {y, y + h * 2 / 3, y + h, y + h * 2 / 3, y};
                g.fillPolygon(sx, sy, 5);
                g.setColor(new Color(255, 255, 255, 200));
                g.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(x + 3, y + h / 2, x + w * 2 / 5, y + h * 2 / 3 - 1);
                g.drawLine(x + w * 2 / 5, y + h * 2 / 3 - 1, x + w - 3, y + h / 4);
                g.setStroke(def);
                break;
            }
            case PERSON: {
                int cx = x + w / 2;
                g.fillOval(cx - w / 5, y, w * 2 / 5, h * 2 / 5);
                g.fillRoundRect(cx - w / 3, y + h * 2 / 5 + 1, w * 2 / 3, h * 3 / 5 - 1, 5, 5);
                // Cap bar
                g.fillRect(cx - w / 3, y + 1, w * 2 / 3, 2);
                break;
            }
            case PLUS: {
                int cx = x + w / 2, cy = y + h / 2, t = 2;
                g.fillRoundRect(x, cy - t, w, t * 2, 2, 2);
                g.fillRoundRect(cx - t, y, t * 2, h, 2, 2);
                break;
            }
            case DOC: {
                g.fillRoundRect(x + 1, y, w - 2, h, 3, 3);
                g.setColor(new Color(0, 0, 0, 70));
                g.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.drawLine(x + 4, y + h / 4,     x + w - 4, y + h / 4);
                g.drawLine(x + 4, y + h / 2,     x + w - 4, y + h / 2);
                g.drawLine(x + 4, y + h * 3 / 4, x + w - 6, y + h * 3 / 4);
                g.setStroke(def);
                break;
            }
        }
    }

    // ── DB refresh ────────────────────────────────────────────────────────
    public void refresh() {
        Statement st = null; ResultSet rs = null;
        try {
            st = DBConnection.get().createStatement();
            rs = st.executeQuery("SELECT * FROM vw_dashboard_stats");
            if (rs.next()) {
                totalRoomsVal.setText(rs.getString("total_rooms"));
                availVal.setText(rs.getString("available_rooms"));
                bookedVal.setText(rs.getString("booked_rooms"));
                maintenanceVal.setText(rs.getString("maintenance_rooms"));
                pendingVal.setText(rs.getString("pending_res"));
                studVal.setText(rs.getString("total_students"));
            }
            DBConnection.close(st);

            recentModel.setRowCount(0);
            st = DBConnection.get().createStatement();
            rs = st.executeQuery(
                "SELECT res_code,student_name,student_id_ref,room_no,status,"
                + "IFNULL(DATE_FORMAT(date_in,'%Y-%m-%d'),''),"
                + "IFNULL(DATE_FORMAT(date_out,'%Y-%m-%d'),''),"
                + "DATE_FORMAT(created_at,'%Y-%m-%d %H:%i') "
                + "FROM reservations ORDER BY created_at DESC LIMIT 12");
            while (rs.next())
                recentModel.addRow(new Object[]{
                    rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
                    rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)});
            recentTbl.getColumnModel().getColumn(4).setCellRenderer(new StatusRenderer());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Dashboard load error:\n" + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DBConnection.close(rs, null); DBConnection.close(st);
        }
    }
}
