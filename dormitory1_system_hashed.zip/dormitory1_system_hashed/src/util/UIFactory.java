package util;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;

/**
 * UTIL LAYER
 * Shared UI component factory. Keeps all views visually consistent.
 */
public class UIFactory {

    public static JTextField field() {
        JTextField f = new JTextField();
        f.setFont(AppTheme.F_BODY);
        f.setPreferredSize(new Dimension(0, 34));
        f.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(AppTheme.INPUT_BORDER, 1, true),
            new EmptyBorder(4, 10, 4, 10)));
        return f;
    }

    public static JPasswordField pass() {
        JPasswordField f = new JPasswordField();
        f.setFont(AppTheme.F_BODY);
        f.setPreferredSize(new Dimension(0, 34));
        f.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(AppTheme.INPUT_BORDER, 1, true),
            new EmptyBorder(4, 10, 4, 10)));
        return f;
    }

    public static JComboBox<String> combo(String... items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setFont(AppTheme.F_BODY);
        cb.setBackground(Color.WHITE);
        cb.setPreferredSize(new Dimension(0, 34));
        return cb;
    }

    public static JLabel lbl(String t) {
        JLabel l = new JLabel(t);
        l.setFont(AppTheme.F_LABEL);
        l.setForeground(AppTheme.TEXT_DARK);
        return l;
    }

    public static JLabel title(String t) {
        JLabel l = new JLabel(t);
        l.setFont(AppTheme.F_SECTION);
        l.setForeground(AppTheme.TEXT_DARK);
        l.setBorder(new EmptyBorder(0, 0, 14, 0));
        return l;
    }

    public static JLabel cardTitle(String t) {
        JLabel l = new JLabel(t);
        l.setFont(AppTheme.F_BOLD);
        l.setForeground(AppTheme.TEXT_DARK);
        l.setBorder(new EmptyBorder(0, 0, 8, 0));
        return l;
    }

    public static JLabel info(String t) {
        JLabel l = new JLabel("  \u2139  " + t);
        l.setFont(AppTheme.F_ITALIC);
        l.setForeground(new Color(0x2471a3));
        l.setBackground(new Color(0xd6eaf8));
        l.setOpaque(true);
        l.setBorder(new EmptyBorder(7, 10, 7, 10));
        return l;
    }

    public static JPanel formCard() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0xe0e0e0), 1, true),
            new EmptyBorder(18, 22, 18, 22)));
        return p;
    }

    public static JPanel tableCard() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(0xe0e0e0), 1, true),
            new EmptyBorder(12, 14, 12, 14)));
        return p;
    }

    public static JTable table(DefaultTableModel m) {
        JTable t = new JTable(m);
        t.setFont(AppTheme.F_TBL);
        t.setRowHeight(38);
        t.setShowGrid(true);
        t.setGridColor(new Color(0xeeeeee));
        t.setSelectionBackground(new Color(0xd5f5ef));
        t.setSelectionForeground(AppTheme.TEXT_DARK);
        t.setAutoCreateRowSorter(true);
        JTableHeader h = t.getTableHeader();
        h.setFont(AppTheme.F_TBL_H);
        h.setBackground(AppTheme.TBL_HEADER);
        h.setForeground(AppTheme.TEXT_DARK);
        h.setPreferredSize(new Dimension(0, 38));
        h.setReorderingAllowed(false);
        DefaultTableCellRenderer c = new DefaultTableCellRenderer();
        c.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < t.getColumnCount(); i++)
            t.getColumnModel().getColumn(i).setCellRenderer(c);
        return t;
    }

    public static JScrollPane scroll(JTable t) {
        JScrollPane s = new JScrollPane(t);
        s.setBorder(new LineBorder(AppTheme.BORDER, 1));
        s.getViewport().setBackground(Color.WHITE);
        return s;
    }

    public static void gridRow(JPanel p, GridBagConstraints g, int y,
                               String l1, JComponent f1, String l2, JComponent f2) {
        g.gridx = 0; g.gridy = y; g.gridwidth = 1; g.weightx = 0.12; p.add(lbl(l1), g);
        g.gridx = 1; g.weightx = 0.38; p.add(f1, g);
        g.gridx = 2; g.weightx = 0.12; p.add(lbl(l2), g);
        g.gridx = 3; g.weightx = 0.38; p.add(f2, g);
    }

    public static void gridWide(JPanel p, GridBagConstraints g, int y, String label, JComponent f) {
        g.gridx = 0; g.gridy = y; g.gridwidth = 1; g.weightx = 0.12; p.add(lbl(label), g);
        g.gridx = 1; g.gridwidth = 3; g.weightx = 0.88; p.add(f, g);
        g.gridwidth = 1;
    }

    public static void gridSingle(JPanel p, GridBagConstraints g, int y, String label, JComponent f) {
        g.gridx = 0; g.gridy = y; g.gridwidth = 1; g.weightx = 0.2; p.add(lbl(label), g);
        g.gridx = 1; g.weightx = 0.8; p.add(f, g);
    }
}
