package util;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class AppTheme {
    // ── Palette ───────────────────────────────────────────────────────────
    public static final Color HEADER_BG     = new Color(0x2c3e50);
    public static final Color SIDEBAR_BG    = new Color(0x34495e);
    public static final Color ACCENT        = new Color(0x1abc9c);
    public static final Color ACCENT_DARK   = new Color(0x16a085);
    public static final Color CONTENT_BG    = new Color(0xf0f2f5);
    public static final Color TBL_HEADER    = new Color(0xecf0f1);
    public static final Color TEXT_DARK     = new Color(0x2c3e50);
    public static final Color BORDER        = new Color(0xdddddd);
    public static final Color INPUT_BORDER  = new Color(0xcccccc);

    public static final Color S_AVAILABLE   = new Color(0x2ecc71);
    public static final Color S_BOOKED      = new Color(0xe74c3c);
    public static final Color S_PENDING     = new Color(0xf39c12);
    public static final Color S_APPROVED    = new Color(0x27ae60);
    public static final Color S_REJECTED    = new Color(0xc0392b);
    public static final Color S_CANCELLED   = new Color(0x95a5a6);
    public static final Color S_CHECKEDIN   = new Color(0x2980b9);
    public static final Color S_CHECKEDOUT  = new Color(0x16a085);
    public static final Color S_MAINTENANCE = new Color(0xe67e22);

    public static final Color BTN_BLUE   = new Color(0x2980b9);
    public static final Color BTN_RED    = new Color(0xe74c3c);
    public static final Color BTN_GRAY   = new Color(0x95a5a6);
    public static final Color BTN_PURPLE = new Color(0x8e44ad);
    public static final Color BTN_ORANGE = new Color(0xe67e22);
    public static final Color BTN_GREEN  = new Color(0x27ae60);

    // ── Fonts ─────────────────────────────────────────────────────────────
    public static final Font F_HEADER  = new Font("Arial", Font.BOLD, 20);
    public static final Font F_SIDEBAR = new Font("Arial", Font.PLAIN, 13);
    public static final Font F_SECTION = new Font("Arial", Font.BOLD, 18);
    public static final Font F_BODY    = new Font("Arial", Font.PLAIN, 13);
    public static final Font F_BOLD    = new Font("Arial", Font.BOLD,  13);
    public static final Font F_BTN     = new Font("Arial", Font.BOLD,  13);
    public static final Font F_TBL     = new Font("Arial", Font.PLAIN, 13);
    public static final Font F_TBL_H   = new Font("Arial", Font.BOLD,  13);
    public static final Font F_LABEL   = new Font("Arial", Font.BOLD,  12);
    public static final Font F_SMALL   = new Font("Arial", Font.PLAIN, 11);
    public static final Font F_ITALIC  = new Font("Arial", Font.ITALIC,11);
    public static final Font F_CARD_V  = new Font("Arial", Font.BOLD,  34);

    // ── Factory methods ───────────────────────────────────────────────────
    public static JButton makeBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(F_BTN);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(0, 36));
        Color dk = bg.darker();
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(dk); }
            public void mouseExited (MouseEvent e) { b.setBackground(bg); }
        });
        return b;
    }

    public static JButton makeSmallBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.BOLD, 11));
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setMargin(new Insets(3, 9, 3, 9));
        Color dk = bg.darker();
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(dk); }
            public void mouseExited (MouseEvent e) { b.setBackground(bg); }
        });
        return b;
    }
}
