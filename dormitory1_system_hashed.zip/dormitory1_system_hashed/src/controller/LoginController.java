package controller;

import model.dao.UserDAO;
import view.LoginView;
import view.MainView;


public class LoginController {

    private final UserDAO userDAO = new UserDAO();
    private final LoginView view;

    public LoginController(LoginView view) {
        this.view = view;
    }

    
    public void handleLogin(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            view.showStatus("Please enter username and password.");
            return;
        }

        view.setLoading(true);

        if (userDAO.authenticate(username, password)) {
            view.dispose();
            new MainView();
        } else {
            view.showStatus("Invalid username or password.");
            view.clearPassword();
            view.setLoading(false);
        }
    }
}
