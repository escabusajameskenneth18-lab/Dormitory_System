package controller;

import model.Room;
import model.dao.RoomDAO;
import view.ManageRoomsView;
import javax.swing.JOptionPane;
import java.sql.SQLIntegrityConstraintViolationException;


public class RoomController {

    private final RoomDAO dao = new RoomDAO();
    private final ManageRoomsView view;
    private final MainController mainCtrl;

    public RoomController(ManageRoomsView view, MainController mainCtrl) {
        this.view     = view;
        this.mainCtrl = mainCtrl;
    }

    public void loadAll() {
        view.populateTable(dao.getAll());
    }

    public void save(Room r, boolean editMode) {
        if (r.getRoomNo().isEmpty()) {
            view.showMessage("Room number is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            if (editMode) {
                dao.update(r);
                view.showMessage("Room updated!", "Updated ✅", JOptionPane.INFORMATION_MESSAGE);
            } else {
                dao.insert(r);
                view.showMessage("Room " + r.getRoomNo() + " added!", "Added ✅",
                                 JOptionPane.INFORMATION_MESSAGE);
            }
            view.clearForm();
            loadAll();
            mainCtrl.refreshAll();
        } catch (SQLIntegrityConstraintViolationException ex) {
            view.showMessage("Room '" + r.getRoomNo() + "' already exists.", "Duplicate",
                             JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            view.showMessage("DB Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void startEdit(int row) {
        String roomNo = (String) view.getTableValueAt(row, 0);
        Room r = dao.getByRoomNo(roomNo);
        if (r != null) view.fillFormForEdit(r);
    }

    public void delete(int row) {
        String roomNo = (String) view.getTableValueAt(row, 0);
        String status = (String) view.getTableValueAt(row, 5);
        if ("Booked".equals(status)) {
            view.showMessage("Cannot delete a booked room.", "Cannot Delete",
                             JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = view.confirmDialog("Delete Room " + roomNo + "?", "Confirm");
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            dao.delete(roomNo);
            loadAll();
            mainCtrl.refreshAll();
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
