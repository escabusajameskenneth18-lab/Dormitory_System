-- ============================================================
-- PASSWORD HASHING MIGRATION
-- dorm_db — dormitory1_system
-- ============================================================
-- Run this script ONCE in phpMyAdmin or MySQL Workbench
-- AFTER updating the Java source files.
--
-- What this does:
--   • Updates the password column to 64 chars (SHA-256 hex length)
--   • Replaces all existing plain-text passwords with their
--     SHA-256 hashes so login still works after the code change.
--
-- Default accounts after migration:
--   admin    / admin123
--   manager  / manager123
--   staff    / staff123
-- ============================================================

-- Step 1: Widen the password column to hold a 64-char SHA-256 hash
ALTER TABLE `users`
  MODIFY COLUMN `password` VARCHAR(64) NOT NULL;

-- Step 2: Replace plain-text passwords with SHA-256 hashes
--         (These are the hashes of the original default passwords)

UPDATE `users` SET `password` = '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9'
  WHERE `username` = 'admin';
-- plain-text was: admin123

UPDATE `users` SET `password` = '866485796cfa8d7c0cf7111640205b83076433547577511d81f8030ae99ecea5'
  WHERE `username` = 'manager';
-- plain-text was: manager123

UPDATE `users` SET `password` = '10176e7b7b24d317acfcf8d2064cfd2f24e154f7b5a96603077d5ef813d6a6b6'
  WHERE `username` = 'staff';
-- plain-text was: staff123

-- Step 3: Verify the update (optional — you can run this SELECT to confirm)
-- SELECT username, role, password FROM users;

-- ============================================================
-- DONE. Passwords are now stored as SHA-256 hashes.
-- The Java app (PasswordUtil.java + UserDAO.java) will
-- automatically hash whatever the user types at login
-- and compare it to the stored hash.
-- ============================================================
