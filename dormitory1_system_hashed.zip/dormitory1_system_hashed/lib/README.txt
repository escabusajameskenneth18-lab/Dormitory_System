PUT YOUR MySQL CONNECTOR JAR HERE
==================================
Download: https://dev.mysql.com/downloads/connector/j/
File name example: mysql-connector-j-8.0.33.jar

After placing the jar:
1. Right-click your project in NetBeans
2. Properties → Libraries → Add JAR/Folder
3. Select this file
