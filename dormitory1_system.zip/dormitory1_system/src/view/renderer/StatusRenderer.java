package view.renderer;

import util.AppTheme;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/**
 * VIEW LAYER — Renderer
 * Colors the Status column in tables based on the reservation/room status value.
 */
public class StatusRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(
            JTable t, Object val, boolean sel, boolean foc, int row, int col) {
        JLabel l = (JLabel) super.getTableCellRendererComponent(t, val, sel, foc, row, col);
        l.setHorizontalAlignment(SwingConstants.CENTER);
        l.setFont(new Font("Arial", Font.BOLD, 11));
        l.setForeground(Color.WHITE);
        l.setOpaque(true);
        String s = val == null ? "" : val.toString();
        switch (s) {
            case "Available":   l.setBackground(AppTheme.S_AVAILABLE);   break;
            case "Booked":      l.setBackground(AppTheme.S_BOOKED);      break;
            case "Pending":     l.setBackground(AppTheme.S_PENDING);     break;
            case "Approved":    l.setBackground(AppTheme.S_APPROVED);    break;
            case "Rejected":    l.setBackground(AppTheme.S_REJECTED);    break;
            case "Cancelled":   l.setBackground(AppTheme.S_CANCELLED);   break;
            case "Checked-In":  l.setBackground(AppTheme.S_CHECKEDIN);   break;
            case "Checked-Out": l.setBackground(AppTheme.S_CHECKEDOUT);  break;
            case "Maintenance": l.setBackground(AppTheme.S_MAINTENANCE); break;
            default:
                l.setBackground(sel ? t.getSelectionBackground() : Color.WHITE);
                l.setForeground(AppTheme.TEXT_DARK);
        }
        return l;
    }
}
