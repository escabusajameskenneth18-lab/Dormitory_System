package controller;

import model.Reservation;
import model.Session;
import model.dao.ReservationDAO;
import model.dao.StudentDAO;
import view.ReservationApprovalView;
import view.RoomReservationView;
import javax.swing.JOptionPane;

/**
 * CONTROLLER LAYER
 * Handles room reservation and approval business logic.
 */
public class ReservationController {

    private final ReservationDAO resDAO  = new ReservationDAO();
    private final StudentDAO     studDAO = new StudentDAO();
    private final MainController mainCtrl;

    public ReservationController(MainController mainCtrl) {
        this.mainCtrl = mainCtrl;
    }

    // ── Room Reservation ────────────────────────────────────────────────

    public void loadRooms(RoomReservationView view) {
        view.populateTable(new model.dao.RoomDAO().getAll());
    }

    public void reserve(RoomReservationView view, int row) {
        String roomNo = (String) view.getTableValueAt(row, 0);
        String status = (String) view.getTableValueAt(row, 5);

        if (!"Available".equals(status)) {
            view.showMessage("Room " + roomNo + " is not available.", "Unavailable",
                             JOptionPane.WARNING_MESSAGE);
            return;
        }
        view.showReservationDialog(roomNo, studDAO.getAll(), (studentName, studentId, dateIn, dateOut, notes) -> {
            try {
                if (resDAO.hasDuplicate(studentId)) {
                    view.showMessage(studentName + " already has an active reservation.", "Duplicate",
                                     JOptionPane.WARNING_MESSAGE);
                    return;
                }
                Reservation r = new Reservation();
                r.setStudentName(studentName); r.setStudentIdRef(studentId);
                r.setRoomNo(roomNo);           r.setDateIn(dateIn);
                r.setDateOut(dateOut);         r.setNotes(notes);
                r.setCreatedBy(Session.getUser());
                resDAO.insert(r);
                view.showMessage("✅ Reservation Saved!\n\nRoom: " + roomNo +
                    "\nStudent: " + studentName + "\nCode: " + r.getResCode(),
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                loadRooms(view);
                mainCtrl.refreshAll();
            } catch (Exception ex) {
                view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public void cancelReservation(RoomReservationView view, int row) {
        String roomNo = (String) view.getTableValueAt(row, 0);
        String resBy  = (String) view.getTableValueAt(row, 6);
        try {
            String code = resDAO.getActiveCodeForRoom(roomNo);
            if (code == null) {
                view.showMessage("No active reservation found.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            int confirm = view.confirmDialog("Cancel reservation for Room " + roomNo + "?\n(Reserved by: " + resBy + ")", "Confirm");
            if (confirm != JOptionPane.YES_OPTION) return;
            resDAO.callProc("sp_cancel_reservation", code, null);
            loadRooms(view);
            mainCtrl.refreshAll();
            view.showMessage("Reservation cancelled. Room " + roomNo + " is now available.", "Cancelled",
                             JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Approval ─────────────────────────────────────────────────────────

    public void loadReservations(ReservationApprovalView view, String filter) {
        view.populateTable(resDAO.getAll(filter));
    }

    public void approve(ReservationApprovalView view, int row) {
        String code   = (String) view.getTableValueAt(row, 0);
        String status = (String) view.getTableValueAt(row, 4);
        if (!"Pending".equals(status)) {
            view.showMessage("Only Pending reservations can be approved.", "Info",
                             JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            resDAO.callProc("sp_approve_reservation", code, Session.getUser());
            loadReservations(view, null);
            mainCtrl.refreshAll();
            view.showMessage("Reservation " + code + " approved!", "Approved ✅",
                             JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void reject(ReservationApprovalView view, int row) {
        String code   = (String) view.getTableValueAt(row, 0);
        String status = (String) view.getTableValueAt(row, 4);
        if (!"Pending".equals(status)) {
            view.showMessage("Only Pending reservations can be rejected.", "Info",
                             JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int confirm = view.confirmDialog("Reject this reservation?\nThe room will be freed.", "Confirm");
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            resDAO.callProc("sp_reject_reservation", code, null);
            loadReservations(view, null);
            mainCtrl.refreshAll();
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void checkIn(ReservationApprovalView view, int row) {
        String code   = (String) view.getTableValueAt(row, 0);
        String status = (String) view.getTableValueAt(row, 4);
        if (!"Approved".equals(status)) {
            view.showMessage("Only Approved reservations can be checked in.", "Info",
                             JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            resDAO.callProc("sp_checkin", code, null);
            loadReservations(view, null);
            mainCtrl.refreshAll();
            view.showMessage("Student checked in!", "Checked In ✅", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void checkOut(ReservationApprovalView view, int row) {
        String code   = (String) view.getTableValueAt(row, 0);
        String status = (String) view.getTableValueAt(row, 4);
        if (!"Checked-In".equals(status)) {
            view.showMessage("Only Checked-In reservations can be checked out.", "Info",
                             JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int confirm = view.confirmDialog("Check out student? Room will be freed.", "Confirm Checkout");
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            resDAO.callProc("sp_checkout", code, null);
            loadReservations(view, null);
            mainCtrl.refreshAll();
            view.showMessage("Student checked out. Room is now available.", "Checked Out ✅",
                             JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void cancelApproval(ReservationApprovalView view, int row) {
        String code = (String) view.getTableValueAt(row, 0);
        int confirm = view.confirmDialog("Cancel reservation " + code + "?", "Confirm");
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            resDAO.callProc("sp_cancel_reservation", code, null);
            loadReservations(view, null);
            mainCtrl.refreshAll();
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void deleteReservation(ReservationApprovalView view, int row) {
        String code = (String) view.getTableValueAt(row, 0);
        int confirm = view.confirmDialog("Permanently delete " + code + "?", "Confirm");
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            resDAO.delete(code);
            loadReservations(view, null);
            mainCtrl.refreshAll();
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
