package controller;

import model.Student;
import model.dao.StudentDAO;
import view.StudentView;
import javax.swing.JOptionPane;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

/**
 * CONTROLLER LAYER
 * Handles all student registration business logic.
 */
public class StudentController {

    private final StudentDAO dao = new StudentDAO();
    private final StudentView view;
    private final MainController mainCtrl;

    public StudentController(StudentView view, MainController mainCtrl) {
        this.view     = view;
        this.mainCtrl = mainCtrl;
    }

    public void loadAll() {
        view.populateTable(dao.getAll());
    }

    public void search(String query) {
        view.populateTable(dao.search(query));
    }

    public void save(Student s, boolean editMode) {
        if (s.getStudentId().isEmpty() || s.getFullName().isEmpty()) {
            view.showMessage("Student ID and Name are required.", "Validation",
                             JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            if (editMode) {
                dao.update(s);
                view.showMessage("Student updated!", "Updated ✅", JOptionPane.INFORMATION_MESSAGE);
            } else {
                dao.insert(s);
                view.showMessage("Student registered!", "Saved ✅", JOptionPane.INFORMATION_MESSAGE);
            }
            view.clearForm();
            loadAll();
            mainCtrl.refreshAll();
        } catch (SQLIntegrityConstraintViolationException ex) {
            view.showMessage("Student ID '" + s.getStudentId() + "' already exists.", "Duplicate",
                             JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            view.showMessage("DB Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void startEdit(int row) {
        Student s = dao.getById((String) view.getTableValueAt(row, 0));
        if (s != null) view.fillFormForEdit(s);
    }

    public void delete(int row) {
        String sid  = (String) view.getTableValueAt(row, 0);
        String name = (String) view.getTableValueAt(row, 1);
        int confirm = view.confirmDialog("Delete " + name + " (" + sid + ")?", "Confirm");
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            dao.delete(sid);
            loadAll();
            mainCtrl.refreshAll();
        } catch (Exception ex) {
            view.showMessage("Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public List<Student> getAllStudents() { return dao.getAll(); }
}
