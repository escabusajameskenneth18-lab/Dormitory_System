package controller;

import model.dao.UserDAO;
import view.LoginView;
import view.MainView;

/**
 * CONTROLLER LAYER
 * Handles login business logic.
 * Sits between LoginView (UI) and UserDAO (database).
 */
public class LoginController {

    private final UserDAO userDAO = new UserDAO();
    private final LoginView view;

    public LoginController(LoginView view) {
        this.view = view;
    }

    /** Called when the user clicks the Login button. */
    public void handleLogin(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            view.showStatus("Please enter username and password.");
            return;
        }

        view.setLoading(true);

        if (userDAO.authenticate(username, password)) {
            view.dispose();
            new MainView();
        } else {
            view.showStatus("Invalid username or password.");
            view.clearPassword();
            view.setLoading(false);
        }
    }
}
