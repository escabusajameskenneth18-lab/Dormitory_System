package controller;

import model.dao.RoomDAO;
import model.dao.StudentDAO;
import model.dao.ReservationDAO;

/**
 * CONTROLLER LAYER
 * Central controller that coordinates refresh across all panels.
 * MainView holds an instance; all other controllers reference it.
 */
public class MainController {

    private view.MainView mainView;

    private final RoomDAO        roomDAO = new RoomDAO();
    private final StudentDAO     studDAO = new StudentDAO();
    private final ReservationDAO resDAO  = new ReservationDAO();

    public void setView(view.MainView view) {
        this.mainView = view;
    }

    /** Called by any controller after a data-changing action. */
    public void refreshAll() {
        if (mainView != null) mainView.refreshAllPanels();
    }

    // Dashboard stats — queried directly from DB
    public int getTotalRooms()    { return roomDAO.getTotalCount(); }
    public int getAvailableRooms(){ return roomDAO.getAvailableCount(); }
    public int getBookedRooms()   { return roomDAO.getBookedCount(); }
    public int getTotalStudents() { return studDAO.getCount(); }
    public int getPendingCount()  { return resDAO.getPendingCount(); }

    public void show(String roomres) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
