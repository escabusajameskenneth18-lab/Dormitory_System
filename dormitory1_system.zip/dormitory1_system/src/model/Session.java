package model;

/**
 * MODEL LAYER
 * Holds the currently logged-in user's session data.
 * Shared across all panels via static access.
 */
public class Session {
    private static int    id       = 0;
    private static String username = "";
    private static String fullName = "";
    private static String role     = "";

    public static void set(int i, String u, String f, String r) {
        id = i; username = u; fullName = f; role = r;
    }
    public static void clear() { id = 0; username = ""; fullName = ""; role = ""; }

    public static int    getId()      { return id; }
    public static String getUser()    { return username; }
    public static String getName()    { return fullName; }
    public static String getRole()    { return role; }
    public static boolean isAdmin()   { return "Admin".equals(role); }
    public static boolean isManager() { return "Admin".equals(role) || "Manager".equals(role); }
}
