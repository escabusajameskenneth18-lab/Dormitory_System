package model;

/**
 * MODEL LAYER — Entity
 * Represents a dormitory room record.
 */
public class Room {
    private String roomNo;
    private String roomType;
    private int    capacity;
    private int    floorNo;
    private double monthlyRate;
    private String status;
    private String reservedBy;

    public Room() {}

    public Room(String roomNo, String roomType, int capacity, int floorNo,
                double monthlyRate, String status, String reservedBy) {
        this.roomNo      = roomNo;
        this.roomType    = roomType;
        this.capacity    = capacity;
        this.floorNo     = floorNo;
        this.monthlyRate = monthlyRate;
        this.status      = status;
        this.reservedBy  = reservedBy;
    }

    // Getters
    public String getRoomNo()      { return roomNo; }
    public String getRoomType()    { return roomType; }
    public int    getCapacity()    { return capacity; }
    public int    getFloorNo()     { return floorNo; }
    public double getMonthlyRate() { return monthlyRate; }
    public String getStatus()      { return status; }
    public String getReservedBy()  { return reservedBy; }

    // Setters
    public void setRoomNo(String roomNo)           { this.roomNo = roomNo; }
    public void setRoomType(String roomType)       { this.roomType = roomType; }
    public void setCapacity(int capacity)          { this.capacity = capacity; }
    public void setFloorNo(int floorNo)            { this.floorNo = floorNo; }
    public void setMonthlyRate(double monthlyRate) { this.monthlyRate = monthlyRate; }
    public void setStatus(String status)           { this.status = status; }
    public void setReservedBy(String reservedBy)   { this.reservedBy = reservedBy; }
}
