package model.dao;

import model.DBConnection;
import model.Student;
import java.sql.*;
import java.util.*;

/**
 * MODEL LAYER — Data Access Object
 * All SQL operations for the students table.
 * Controllers call these methods; Views never touch SQL.
 */
public class StudentDAO {

    public List<Student> getAll() {
        List<Student> list = new ArrayList<>();
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "SELECT student_id, full_name, course, email, contact, gender, address " +
                "FROM students ORDER BY full_name");
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Student(
                    rs.getString("student_id"), rs.getString("full_name"),
                    nvl(rs.getString("course")),  nvl(rs.getString("email")),
                    nvl(rs.getString("contact")), nvl(rs.getString("gender")),
                    nvl(rs.getString("address"))
                ));
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        finally { DBConnection.close(rs, ps); }
        return list;
    }

    public List<Student> search(String query) {
        List<Student> list = new ArrayList<>();
        PreparedStatement ps = null; ResultSet rs = null;
        String q = "%" + query + "%";
        try {
            ps = DBConnection.get().prepareStatement(
                "SELECT student_id, full_name, course, email, contact, gender, address " +
                "FROM students WHERE student_id LIKE ? OR full_name LIKE ? OR course LIKE ? ORDER BY full_name");
            ps.setString(1, q); ps.setString(2, q); ps.setString(3, q);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Student(
                    rs.getString("student_id"), rs.getString("full_name"),
                    nvl(rs.getString("course")),  nvl(rs.getString("email")),
                    nvl(rs.getString("contact")), nvl(rs.getString("gender")),
                    nvl(rs.getString("address"))
                ));
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        finally { DBConnection.close(rs, ps); }
        return list;
    }

    public Student getById(String studentId) {
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement("SELECT * FROM students WHERE student_id=?");
            ps.setString(1, studentId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return new Student(
                    rs.getString("student_id"), rs.getString("full_name"),
                    nvl(rs.getString("course")),  nvl(rs.getString("email")),
                    nvl(rs.getString("contact")), nvl(rs.getString("gender")),
                    nvl(rs.getString("address"))
                );
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        finally { DBConnection.close(rs, ps); }
        return null;
    }

    /** Returns true if inserted successfully, false if duplicate. */
    public boolean insert(Student s) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "INSERT INTO students(student_id, full_name, course, email, contact, gender, address) " +
                "VALUES(?,?,?,?,?,?,?)");
            ps.setString(1, s.getStudentId()); ps.setString(2, s.getFullName());
            ps.setString(3, s.getCourse());    ps.setString(4, s.getEmail());
            ps.setString(5, s.getContact());   ps.setString(6, s.getGender());
            ps.setString(7, s.getAddress());
            ps.executeUpdate();
            return true;
        } finally { DBConnection.close(null, ps); }
    }

    public void update(Student s) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "UPDATE students SET full_name=?, course=?, email=?, contact=?, gender=?, address=? WHERE student_id=?");
            ps.setString(1, s.getFullName());  ps.setString(2, s.getCourse());
            ps.setString(3, s.getEmail());     ps.setString(4, s.getContact());
            ps.setString(5, s.getGender());    ps.setString(6, s.getAddress());
            ps.setString(7, s.getStudentId());
            ps.executeUpdate();
        } finally { DBConnection.close(null, ps); }
    }

    public void delete(String studentId) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = DBConnection.get().prepareStatement("DELETE FROM students WHERE student_id=?");
            ps.setString(1, studentId);
            ps.executeUpdate();
        } finally { DBConnection.close(null, ps); }
    }

    public int getCount() {
        try {
            Statement st = DBConnection.get().createStatement();
            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM students");
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) { return 0; }
    }

    private String nvl(String s) { return s == null ? "" : s; }
}
