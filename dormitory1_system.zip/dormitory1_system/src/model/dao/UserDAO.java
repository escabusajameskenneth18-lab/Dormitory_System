package model.dao;

import model.DBConnection;
import model.Session;
import java.sql.*;

/**
 * MODEL LAYER — Data Access Object
 * Handles user authentication.
 */
public class UserDAO {

    /**
     * Authenticates the user. If successful, sets the Session.
     * @return true if login succeeded, false otherwise.
     */
    public boolean authenticate(String username, String password) {
        PreparedStatement ps = null; ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement(
                "SELECT id, username, full_name, role FROM users WHERE username=? AND password=?");
            ps.setString(1, username); ps.setString(2, password);
            rs = ps.executeQuery();
            if (rs.next()) {
                Session.set(rs.getInt("id"), rs.getString("username"),
                            rs.getString("full_name"), rs.getString("role"));
                return true;
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        finally { DBConnection.close(rs, ps); }
        return false;
    }
}
