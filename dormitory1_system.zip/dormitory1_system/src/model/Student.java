package model;

/**
 * MODEL LAYER — Entity
 * Represents a student record from the database.
 */
public class Student {
    private String studentId;
    private String fullName;
    private String course;
    private String email;
    private String contact;
    private String gender;
    private String address;

    public Student() {}

    public Student(String studentId, String fullName, String course,
                   String email, String contact, String gender, String address) {
        this.studentId = studentId;
        this.fullName  = fullName;
        this.course    = course;
        this.email     = email;
        this.contact   = contact;
        this.gender    = gender;
        this.address   = address;
    }

    // Getters
    public String getStudentId() { return studentId; }
    public String getFullName()  { return fullName; }
    public String getCourse()    { return course; }
    public String getEmail()     { return email; }
    public String getContact()   { return contact; }
    public String getGender()    { return gender; }
    public String getAddress()   { return address; }

    // Setters
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public void setFullName(String fullName)   { this.fullName = fullName; }
    public void setCourse(String course)       { this.course = course; }
    public void setEmail(String email)         { this.email = email; }
    public void setContact(String contact)     { this.contact = contact; }
    public void setGender(String gender)       { this.gender = gender; }
    public void setAddress(String address)     { this.address = address; }
}
